Zoeken
======

Met deze module kan gezocht worden in de database.
De volgende zoektermen zijn mogelijk:

- een enkel woord - resultaat bestaat uit items waar het woord in voorkomt
- meerdere lossen woorden - resultaat bestaat uit items waar alle woord in voorkomen
- "woorden tussen quotes" - resultaat bestaat uit items waar de tekst tussen qoutes letterlijk in voorkomt
- een combinatie van bovenstaand

Bestanden
---------

- site/config/search.php - Hier kun je een een aantal dingen instellen
- site/views/search/*.php - De views
- site/language/##/search_lang.php - Taalbestanden

Installatie
-----------

- Pas de configuratie aan indien nodig (zie: site/config/search.php)
- Pas de view (en styling) aan indien nodig
- Maak je eigen taalbestand en/of wijzig de bestaande

1) Zoeken op eigen pagina
-------------------------

- Maak een pagina aan waar het zoekresultaat getoond moet worden, en geef die de module 'search'.

2) Zoekveld op elke pagina
--------------------------

- Stel in site/config.php: <span class="code">$config['autoload_modules'] = array('search.form');</span>
- Maak een plekje in de hoofdview (site/views/site.php) waar je het zoekformulier toont: <span class="code">&lt;?=$modules['search.form']?&gt;</span>
- Maak een pagina aan waar het zoekresultaat getoond moet worden, en geef die de module 'search'.


@author Jan den Besten

@package FlexyAdmin_comments

	

packed files
------

- site/config/search.php
- site/language/en/search_lang.php
- site/language/nl/search_lang.php
- site/libraries/search.php
- site/views/search/form.php
- site/views/search/results.php

'flexyadmin_search.zip' is a flexyadmin module - packed at 06 feb 2015 12:51
www.flexyadmin.com