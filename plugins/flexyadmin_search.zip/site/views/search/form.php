<form id="search_form" action="<?=$action?>" method="POST" role="form">
  <input id="__form_id" class="__form_id hidden" type="hidden" value="search_form" name="__form_id"></input>
  <div class="form-group">
    <input id="search_term" class="form-control" name="search" value="<?=$value?>" placeholder="<?=$placeholder?>" />
  </div>
</form>