<?php


$lang['search_term']='search';
$lang['search_empty_value']='Zoeken';


?>