Google Map
=========

- Toon een Google Map met één adres
- Of toon een Map met meerdere adressen

Bestanden
----------------

- site/config/google_map.php - Hier kun je een een aantal dingen instellen
- db/add_google_map.sql - database bestand
- site/views/google_map.php - De view waarin de map komt
- site/views/google_map_popup.php - view waarin de popup gemaakt wordt

Installatie
----------------

- Voeg de module 'google_map' toe aan een pagina
- Als je één adres wilt tonen, voer dat adres in tbl_site in.
- Als je meerdere adressen wilt tonen stel `$config['multiple'] = TRUE` en voer de adressen in in de tabel `tbl_gm_addresses`


@author Jan den Besten

@package FlexyAdmin_comments

	

packed files
------

- db/add_google_map.sql
- site/config/google_map.php
- site/libraries/GMap.php
- site/libraries/google_map.php
- site/views/google_map/google_map.php
- site/views/google_map/popup.php

'flexyadmin_google_map.zip' is a flexyadmin module - packed at 06 feb 2015 13:28
www.flexyadmin.com