<h1><?=$str_title?></h1>
<p><b><?=$str_address?></b></p>
<div>
<? if (isset($txt_text)): ?><?=$txt_text?><? endif ?>
<? if (isset($url_url)): ?><a href="<?=$url_url?>" target="_blank"><?=trim(str_replace('http://','',$url_url),'/')?></a><? endif ?>
</div>