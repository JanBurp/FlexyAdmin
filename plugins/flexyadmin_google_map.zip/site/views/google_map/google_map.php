<div id="google_map">
	<?=$headerjs?>
	<?=$headermap?>
	
	<h1>Google Map</h1>
	<?=$onload?>
	<?=$map?>
	<!-- <?=$sidebar?> -->
</div>
