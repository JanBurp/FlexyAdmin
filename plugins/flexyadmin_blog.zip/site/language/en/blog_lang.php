<?php

$lang['read_more']='read more';


?>