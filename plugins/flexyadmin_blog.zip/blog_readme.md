Eenvoudige blog module
======================

Maak gebruik van een samengesteld menu: zorg dat eerst `add_auto_menu.sql` is geinstalleerd.
Kan uitgebreid worden met `plugin_comments` om reacties te koppelen.

Bestanden
----------------

- site/config/blog.php - Hier kun je een een aantal dingen instellen
- db/add_simple_blog.sql - database bestand met de benodigde tabel
- site/views/blog.php - De view waarin de blog geplaatst worden

Installatie
----------------

- Zorg dat `add_auto_menu.sql` is geladen, als dat niet is gebeurt, doe dat alsnog en installeer daarna deze plugin opnieuw
- Maak een menu item aan met de module 'blog'


@author Jan den Besten

@package FlexyAdmin_blog
 	

packed files
------

- db/add_simple_blog.sql
- site/config/blog.php
- site/language/en/blog_lang.php
- site/language/nl/blog_lang.php
- site/libraries/blog.php
- site/views/blog/blog.php
- site/views/blog/latest.php
- site/views/blog/page.php

'flexyadmin_blog.zip' is a flexyadmin module - packed at 06 feb 2015 15:34
www.flexyadmin.com