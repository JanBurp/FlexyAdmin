#
# TABLE STRUCTURE FOR: tbl_blog
#

DROP TABLE IF EXISTS tbl_blog;

CREATE TABLE `tbl_blog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `uri` varchar(100) NOT NULL,
  `str_title` varchar(255) NOT NULL DEFAULT '',
  `dat_date` date NOT NULL,
  `txt_text` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;


# UPDATE_IF:Add dat_date to res_menu_result?
ALTER TABLE `res_menu_result` ADD `dat_date` DATE  NOT NULL  AFTER `str_title`;
INSERT INTO `cfg_auto_menu` (`id`, `uri`, `order`, `self_parent`, `str_parent_uri`, `b_active`, `str_description`, `str_type`, `b_keep_parent_modules`, `table`, `field_group_by`, `str_parent_where`, `str_where`, `int_limit`, `str_parameters`) VALUES (NULL, '', '0', '0', '', '1', 'Blog', 'from submenu table', '1', 'tbl_blog', '', 'str_module = \"blog\"', '', '0', '');

