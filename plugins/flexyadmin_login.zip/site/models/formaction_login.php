<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Formaction_login extends Formaction {

   /**
    * @author Jan den Besten
    * @ignore
    */
   public function __construct() {
     parent::__construct();
   }
   
   /**
    * Voer de actie uit, in dit geval: stop de data in de database
    *
    * @param string $data data teruggekomen van het formulier
    * @return int id van toegevoegde data in de database
    * @author Jan den Besten
    * @ignore
    */
  public function go($data) {
    parent::go($data);
    $method='login_'.$this->form_id;
    return $this->$method($data);
  }


  /**
   * Validate username & password (valid_model_method)
   * Test if user filled in username & password, if so, login and if that works: validation is ok, else an error
   *
   * @param string $pass 
   * @return mixed
   * @author Jan den Besten
   */
  public function valid_login($password) {
    $username = $_POST['str_login_username'];
    $remember = el('remember_user',$this->settings,false);
    if (isset($_POST['b_login_remember'])) $remember=$_POST['b_login_remember'];
    if (!empty($username) && !empty($password)) {
      $result  = $this->flexy_auth->login($username, $password, $remember);
      if ($result) return TRUE;
    }
    return 'login_error';
  }
  
  
  /**
   * If user is not logged in, log in
   *
   * @param string $data 
   * @return bool
   * @author Jan den Besten
   */
  private function login_login($data) {
    if (!$this->flexy_auth->logged_in()) {
      $u = $data['str_login_username'];
      $p = $data['gpw_login_password'];
      if (!empty($u) && !empty($p)) {
        $result  = $this->flexy_auth->login($u, $p, $data['b_login_remember']);
      }
    }
    if (isset($this->settings['redirect'])) {
      $redirect=$this->settings['redirect'];
      redirect($redirect);
    }
    return true;
  }



  /**
   * Checkt of email adres al bestaat
   *
   * @param string $email 
   * @return bool
   * @author Jan den Besten
   */
  public function valid_check_unique_email($email) {
    if ($this->flexy_auth->email_check($email)) {
      return 'email_used';
    }
    return TRUE;
  }
  
  
  /**
   * Checkt of het een bestaand email is of niet
   *
   * @param string $email 
   * @return void
   * @author Jan den Besten
   */
  public function valid_check_if_existing_email($email) {
    if ($this->flexy_auth->email_check($email)) {
      return TRUE;
    }
    return 'email_not_found';
  }
  


  /**
   * Register new user
   *
   * @param string $data 
   * @return bool
   * @author Jan den Besten
   */
  private function login_register($data) {
    $return=FALSE;
    // Register
    $user_id = $this->flexy_auth->register(
      $data['str_login_username'],
      $data['gpw_login_password'],
      $data['email_login_email'],
      $this->settings['group_id'],
      false,
      lang('register_mail_subject'),
      $this->settings['register_uri']
    );
    
    if ($user_id) {
      // Store extra fields. Addition by Deka Webdesign
      if ($this->settings['extra_data']) {
        unset($data['str_login_username']);
        unset($data['gpw_login_password']);
        unset($data['gpw_login_password2']);
        unset($data['email_login_email']);
        $data['id_user'] = $user_id;
        // insert in db
        $this->db->insert( $this->settings['extra']['table'], $data );
      }

      if ($this->settings['admin_activation']) {
        $return=lang('register_wait');
      }
      else {
        $return=lang('register_completed');
      }
    }
    else {
      $return=$this->flexy_auth->get_error();
    }
    
    $this->session->set_userdata('_thanks',$return);
    return $return;
  }
  
  public function register_thanks() {
    $thanks=$this->session->userdata('_thanks');
    return $thanks;
  }
  
  
  /**
   * Forgot password
   *
   * @param string $data 
   * @return bool
   * @author Jan den Besten
   */
  private function login_forgot_password($data) {
		// Complete
    $this->flexy_auth->set_forgotten_password_uri( $this->settings['forgotten_password_uri'] );
		if ($this->flexy_auth->forgotten_password( $data['email'] ) ) {
			return 'forgot_password_completed';
		}
    return 'forgot_password_unsuccessful';
  }
  
  

}
