<?php


/**
	* Login
	* =====
	*
	* Deze module kan gebruikt worden om bezoekers te laten inloggen op de site.
	* Dit kan voor de hele site, maar ook per pagina.
	*
	* Installatie
	* -----------
	* 
	* - Als inloggen voor de alle pagina's nodig is: laad de module dan automatisch in met `$config['autoload_modules'] = array('login');` in site/config/config.php
	* - Als inloggen alleen op enkele pagina's nodig is: laad de module dan alleen in op die pagina's `$config['autoload_modules_if'] = array( 'login'=>array('b_restricted'=>'true') );`
	* 
	* - Er wordt automatisch een `tbl_login_menu` aangemaakt met alle nodige pagina's erin:
	* - Je moet in het menu in ieder geval een pagina hebben met de module 'login.logout'.
	* - Een pagina met de module 'login.login' is niet noodzakelijk omdat die automatisch wordt getoond indien nodig.
	* - Als gebruikers zelf hun paswoord moeten kunnen resetten dan moet ergens in het menu een pagina bestaan met de module 'login.forgot_password'.
	* - Als gebruikers zichzelf moeten kunnen registreren dan moet ergens in het menu een pagina bestaan met de module 'login.register'.
	* - Als gebruikers hun gegevens zelf moeten kunnen aanpassen dan moet ergens in het menu een pagina bestaan met de module 'login.edit'.
	* 
	* @version 2.0.0
	* @author Jan den Besten
	* @package FlexyAdmin_login
	**/

class Login extends Module {
	
	private $errors = '';
	private $form;
	
  /**
   * @ignore
   */
   public function __construct() {
		parent::__construct();
    $this->CI->load->library('forms');
		$this->CI->load->library('flexy_auth');

    // Don't cache this page
    $this->CI->config->set_item('dont_cache_this_page',TRUE);
    
    // Find URLS
    if ($this->config('auto_uris')) $this->_find_uris();
    
    // Set flexy_auth config
    $flexy_auth_config = $this->config('flexy_auth');
    $this->CI->flexy_auth->set_config( $flexy_auth_config );
    
    // Set standard variables
    $this->_set_user_globals();
	}
  
  private function _set_user_globals() {
    $user = $this->CI->flexy_auth->get_user();
    $this->CI->site['user_id']     = $user['id'];
    $this->CI->site['username'] = $user['username'];
    return $this;
  }
  
	
  /**
  	* Hier wordt de module standaard aangeroepen
  	* - Als nog niet is ingelogd dan wordt login.login aangeroepen
  	* - Anders wordt de normale pagina getoond.
  	*
  	* @param string $page
  	* @return string 
  	* @author Jan den Besten
  	* @ignore
  	*/
	public function index($page) {
    $modules = $this->CI->site['modules'];
    if (one_of_array_in_array( array('login.login','login.logout','login.register','login.forgot_password','login.reset_password'), $modules )	) {
      return $page;
    }
		return $this->login($page,false);
	}
  
  // /**
  //  * Checks if user is logged in, sets class and username
  //  *
  //  * @param array $page
  //  * @return array $page
  //  * @author Jan den Besten
  //  */
  // public function username( $page ) {
  //   $this->remember_current_page();
  //     if ($this->CI->flexy_auth->logged_in()) {
  //     $this->CI->add_class($this->config('class'));
  //     return $this->CI->session->userdata("str_username");
  //     }
  //   return '';
  // }
	
  
  /**
  	* Als nog niet is ingelogd toon dan inlog formulier
  	*
  	* @param array $page 
  	* @param bool $show_if_allready[true]
  	* @return mixed
  	* @author Jan den Besten
  	*/
   public function login($page, $show_if_allready=true) {
    if ( $this->CI->flexy_auth->logged_in() ) {
      $this->_set_user_globals();
      return '';
    }

    // Onthou de huidige URL
    $this->remember_current_page();
    
    // Moet (rest) van huidige pagina getoond worden?
    $show_page = $this->config('show_page');
    if ( is_array($show_page) ) {
      $key=key($show_page);
      $value=current($show_page);
      if ( !isset($page[$key]) ) {
        $show_page=FALSE;
      }
      else {
        $show_page = ($page[$key]===$value);  
      }
    }
    if (!$show_page) $this->break_content();
    
    // Toon login formulier
    $form = $this->config['forms']['login'];
    if ( !$this->config('dont_redirect')) $form['redirect'] = $this->get_current_page();
    $this->CI->forms->initialize( 'login',$form );
    $view['form'] = $this->CI->forms->login();

    // Forgotten password & register link
    if ( $this->config('forgotten_password_uri') ) {
      $view['forgotten_password'] = lang('forgot_password');
      $view['forgotten_password_uri'] = $this->config('forgotten_password_uri');
    }
    if ( $this->config('register_uri') ) {
      $view['register'] = lang('register');
      $view['register_uri'] = $this->config('register_uri');
    }
    
    // Render
    $this->CI->add_class('login_form');
		return $this->_show( $page, $this->CI->show('login/login',$view,true) );
	}
	
  
	/**
		* Uitloggen van huidige gebruiker
		*
		* @param string $page 
		* @return string
		* @author Jan den Besten
		*/
	public function logout($page) {
    $redirect = $this->get_current_page();
		$this->CI->flexy_auth->logout();
    if ($redirect) redirect($redirect);
    return $this->_show( $page,lang('logout_done') );
	}
  
	
	
  /**
  	* Reset wachtwoord (gebruiker krijgt een mail)
  	*
  	* @param string $page 
  	* @return string
  	* @author Jan den Besten
  	*/
  public function forgot_password($page) {
		$content='';
		$code=$this->CI->input->get('code');
    
		if ($code) {
			// reset password
      $user_id=$this->CI->db->get_field_where('cfg_users','id','forgotten_password_code',$code);
      $extra_emails=$this->_extra_emails($user_id);
			$reset = $this->CI->flexy_auth->forgotten_password_complete($code);
			if ($reset) {
				$content=langp('reset_password_succes',$this->config('login_uri'));
			}
			else {
				$content=lang('reset_password_error');
			}
		}
		else {
			// show form to reset password
      $content=p().lang('forgot_password_intro')._p();
      $form=$this->config['forms']['forgot_password'];
      $form['forgotten_password_uri']=$this->config('forgotten_password_uri');
      $this->CI->forms->initialize('forgot_password',$form);
      $content.=$this->CI->forms->forgot_password();
		}
		return $this->_show($page,$content);
	}
  

  /**
  	* Registreer nieuwe gebruiker (gebruiker krijgt een mail)
  	*
  	* @param string $page 
  	* @return string
  	* @author Jan den Besten
  	*
  	* LET OP: deze method werkt alleen met de volgende instelling in site/config/config.php:
  	* <code> $config['query_urls']&nbsp;=&nbsp;TRUE;</code>
  	*/
	public function register($page) {
		$errors		= '';
		$content	= '';
		
		$id=$this->CI->input->get('id');
		$activation=$this->CI->input->get('activation');
		if ($id and $activation) {
			if ($this->CI->flexy_auth->activate($id,$activation)) {
				$content=langp('register_succes',$this->config('login_uri'));
			}
			else {
				$content=langp('register_fail');
			}
		}
		else {
			// Allready logged in
			if ($this->CI->flexy_auth->logged_in()) {
				$content=langp('login_already',$this->CI->flexy_auth->user_name);
			}
			else {
				// Register form
        $form=$this->config['forms']['register'];
        $form['group_id']=$this->config('group_id');
        $form['extra_data']=$this->config('extra_data');
        $form['extra']=$this->config('extra');
        $form['admin_activation']=$this->config('admin_activation');
        $form['register_uri']=$this->config('register_uri');
        $this->CI->forms->initialize('register',$form);
        $content.=$this->CI->forms->register();
			}
		}
		return $this->_show($page,$content);
	}
  

  /**
   * Hier kan de gebruiker dingen aanpassen, via een model waarvan de naam in de config kan worden ingesteld.
   *
   * @param string $page 
   * @return string $page
   * @author Jan den Besten
   */
  public function edit($page) {
		if (!$this->CI->flexy_auth->logged_in()) {
      return $this->login($page);
    }
    $content='';
    
    if (isset($this->config['edit_model']) and !empty($this->config['edit_model'])) {
      // Handel alles af via het model, en stuur de output door naar meegegeven view (als die er is)
      $edit_model=$this->config['edit_model'];
      $this->CI->load->model($edit_model);
      $result=$this->CI->$edit_model->edit($page);
      if (isset($result['view'])) {
        $content=$this->CI->view($result['view'],$result,true);
      }
      else $page=array_merge($page,$result);
    }
    else {
      // een eenvoudig edit formulier
      $form=$this->config['forms']['edit'];
      $this->CI->forms->initialize('edit',$form);
      $content.=$this->CI->forms->edit();
    }
    
		return $this->_show($page,$content);
  }



  /**
   * Onthoud huidige pagina
   *
   * @return void
   * @author Jan den Besten
   */
  private function remember_current_page() {
    $current=$this->CI->uri->get();
    if ($current!=$this->config['login_uri'] and $current!=$this->config['logout_uri'] and $current!=$this->config['register_uri'] and $current!=$this->config['forgotten_password_uri']) {
      $this->CI->session->set_userdata('login_current_page',$current);
    }
  }
  
  /**
   * Geeft onthouden pagina op
   *
   * @return mixed De uri van de pagina, of FALSE
   * @author Jan den Besten
   */
  private function get_current_page() {
    $current=$this->CI->session->userdata('login_current_page');
    return $current;
  }
  

  /**
   * Geeft extra email van gebruiker
   *
   * @param string $user_id 
   * @return string
   * @author Jan den Besten
   */
  private function _extra_emails($user_id) {
    $extra_emails='';
    if (isset($this->config['extra_email_table']) and !empty($this->config['extra_email_table'])) {
      $table=$this->config['extra_email_table'];
      $fields=$this->CI->db->list_fields($table);
      $fields=filter_by($fields,'email');

      $this->CI->db->select($fields);
      $this->CI->db->where('id_user',$user_id);
      $u=$this->CI->db->get_row($table);
      if ($u) $extra_emails=trim(implode(',',$u),',');
    }
    return $extra_emails;
  }


  /**
  	* @param string $page 
  	* @param string $content
  	* @return void
  	* @author Jan den Besten
  	* @ignore
  	*/
	private function _show($page,$content) {
    if (empty($content)) return '';
		$content='<div id="login">'.$content.'</div>';
		return $this->CI->view('login/main', array('content'=>$content),true);
	}
  

  /**
  	* @return void
  	* @author Jan den Besten
  	* @ignore
  	*/
   private function _find_uris() {
		$this->config['login_uri']              = find_module_uri('login.login');
		$this->config['logout_uri']             = find_module_uri('login.logout');
		$this->config['register_uri']           = find_module_uri('login.register');
		$this->config['forgotten_password_uri'] = find_module_uri('login.forgot_password');
    return $this;
	}
	

}

?>
