<p class="text-warning">Je moet eerst inloggen om deze pagina te kunnen bekijken.</p>

<?php if (isset($errors)): ?><div class="loginErrors"><?=$errors?></div><?php endif ?>
<div class="loginForm"><?=$form?></div>
<br />
<p>
<? if (isset($forgotten_password)): ?>
	<a href="<?=$forgotten_password_uri?>"><?=$forgotten_password?></a><br />
<? endif ?>
<? if (isset($register)): ?>
	<a href="<?=$register_uri?>"><?=$register?></a>
<? endif ?>
</p>
