<div id="login">
<?=$content?>
</div>