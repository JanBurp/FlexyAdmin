<form action="<?=site_url()?>" method="post" class="login">
	<p><label for="user">Naam</label><input type="text" name="user" value="" id="user" class="user" /></p>
	<p><label for="pass">Password</label><input type="password" name="password" value="" id="password" class="password"  /></p>
	<input type="submit" name="" value="Login" submit="submit" class="button submit"  />
</form>
