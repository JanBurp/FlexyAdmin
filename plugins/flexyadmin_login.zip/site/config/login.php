<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Files belonging to this module/plugin
 */
$config['_files']=array(
  'site/models/formaction_login.php',
  'site/models/formaction_login_edit.php',
  'site/views/login/*',
  'db/add_login_menu.sql'
);

/**
 * Output routing of module.methods
 */
$config['__return']='page';
$config['__return.username']='site';


/**
 * URLS van de inlog,registratie,vergeten wachtwoord etc pagina's.
 * Hier kun je die hard instellen, standaard worden ze automatisch gezocht in de menustructuur.
 */
$config['auto_uris']=true;
// $config['login_uri']='';
// $config['logout_uri']='';
// $config['register_uri']='';
// $config['forgotten_password_uri']='';


/*
|--------------------------------------------------------------------------
| Dont Redirect to current page after login
|--------------------------------------------------------------------------
|
| Set to true if using forms and uri queries
|
*/
// $config['dont_redirect'] = FALSE;


/**
 * Als niet is ingelogd, word de variabele $show_page = FALSE in een view zodat je kunt bepalen welke inhoud wel/niet mag worden getoond.
 * Hier kun je instellen dat $show_page altijd TRUE wordt of afhankelijk is van een module
 */
$config['show_page'] = FALSE;  // default = FALSE
// $config['show_page'] = TRUE;
// $config['show_page'] = array('str_module'=>'show_allways');



/*
|--------------------------------------------------------------------------
| Login css class
|--------------------------------------------------------------------------
|
| This class will be added to the body tag if a uses is logged in (if the module is loaded offcoz)
|
*/
$config['class']='user_logged_in';


/**
 * FlexyAuth config (overschrijft de standaard ion auth config, zie sys/flexyadmin/config/ion_auth)
 * De belangrijkste en meest waarschijnlijke staan hieronder met hun defaults.
 */
$config['flexy_auth'] = array(
  // 'default_group'              => 'visitor',    // Default group, use name
  // 'email_activation'           => FALSE,        // Email Activation for registration
  // 'manual_activation'          => FALSE,        // Manual Activation for registration
  'remember_users'             => TRUE,         // Allow users to be remembered and enable auto-login
  'track_login_attempts'       => TRUE,         // Track the number of failed login attempts for each user or ip.
  // 'maximum_login_attempts'     => 3,            // The maximum number of failed login attempts.
  // 'lockout_time'               => 600,          // The number of seconds to lockout an account due to exceeded attempts
);



/*
|--------------------------------------------------------------------------
| Extra fields settings
|--------------------------------------------------------------------------
|
| If you like, you can add extra fields to the register form
| These data will be stored in the table you specify below
| Be aware not to use different fieldnames then cfg_users
| Add the fields $config['forms']['register']
 */
// $config['extra_data'] = false;
// $config['extra']['table'] = 'tbl_leden';
// $config['extra']['formdata'] = array('str_voornaam','str_achternaam','str_adres','str_postcode','str_woonplaats');  // Geef de rest van de veldinfo bovenaan bij forms aan



/**
 * Formulieren voor inloggen, registreren etc.
 */
$config['forms'] = array(
  
  'login' => array(
    'title'               => lang('login_submit'),
  	'fields'              => array(
                              "str_login_username"			=> array("label"=>lang('username'),"validation"=>"required"),
										          "gpw_login_password"			=> array('type'=>'password', "label"=>lang('password'),"validation"	=>  "required|valid_model_method[formaction_login.valid_login]"),
                              // "b_login_remember"        => array('type'=>'checkbox', "label"=>lang('remember'))
                            ),
    'validation_place'    => 'field',
    'buttons'             => array('submit'=>array("submit"=>"login_submit","value"=>lang('login_submit'))),
    'formaction'          => 'formaction_login',
    'thanks'              => lang('login_already'),
    'remember_user'       => true,
  ),
  
  'register' => array(
  	'fields'              => array(
                              "str_login_username"=>array("label"=>lang('username'), "validation"	=>  "required|alpha_dash|is_unique[cfg_users.str_username]"),
															"gpw_login_password"=>array("type"=>'password', "label"=>lang('password'), "validation"	=>  "required|valid_password"),
															"gpw_login_password2"=>array("type"=>'password', "label"=>lang('password2'), "validation"	=>  "required"),
															"email_login_email"	=>array("label"=>lang('email'),"validation"	=>  "required|valid_email|valid_model_method[formaction_login.valid_check_unique_email]"),
                            ),
    'validation_place'    => 'field',
    'buttons'             => array('submit'=>array("submit"=>"submit","value"=>lang('register_submit'))),
    'formaction'          => 'formaction_login',
    'thanks_model'        => 'formaction_login.register_thanks',
  ),

  'forgot_password' => array(
  	'fields'              => array("email"	=>array("label"=>"Email","validation"	=>  "required|valid_email|valid_model_method[formaction_login.valid_check_if_existing_email]")),
    'validation_place'    => 'field',
    'buttons'             => array('submit'=>array("submit"=>"submit","value"=>lang('forgot_password_submit'))),
    'formaction'          => 'formaction_login',
    'thanks'              => lang('forgot_password_completed')
  ),
  
  'edit' => array(
  	'fields'              => array(
                              'id'              => array( 'type'=>'hidden'),
                              'str_username'		=> array( 'label'=>lang('username'), 'validation'=>'required|min_length[4]|max_length[20]|is_unique[cfg_users.str_username.id]' ),
                              'email_email'	    => array( 'label'=>lang('email'),    'validation'=>'trim|valid_email|max_length[100]|is_unique[cfg_users.email_email.id]' ),
                              // 'gpw_password'   => array( 'type'=>'password', 'label'=>lang('password'), 'validation'=>'trim|valid_password|max_length[40]'),
                              // Extra fields
                              // 'str_voornaam'   => array( 'label'=>'voornaam', 'validation'=>'required|min_length[4]|max_length[40]'), 
                              // 'str_achternaam'   => array( 'label'=>'achternaam', 'validation'=>'min_length[4]|max_length[40]'),
                              // 'str_adres'   => array( 'label'=>'adres', 'validation'=>'min_length[4]|max_length[60]'),     
                              // 'str_postcode'   => array( 'label'=>'postcode', 'validation'=>'min_length[4]|max_length[7]'),     
                              // 'str_woonplaats'   => array( 'label'=>'woonplaats', 'validation'=>'min_length[4]|max_length[40]'),
                            ),
    'populate_fields'     => 'formaction_login_edit.populate',
    'add_password_match'  => true,
    'validation_place'    => 'field',
    'buttons'             => array('submit'=>array("submit"=>"submit","value"=>lang('edit_submit'))),
    'formaction'          => 'formaction_login_edit',
    'thanks'              => lang('edit_changed')
  ),

);



/**
 * Hier kun je een ander model instellen waarmee user stettings moeten kunnen worden ingesteld. Standaard is dat formaction_login_edit
 */
// $config['edit_model']     = '';



/* End of file config.php */
/* Location: ./system/application/config/config.php */
