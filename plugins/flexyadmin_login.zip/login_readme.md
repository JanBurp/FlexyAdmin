Login
=====

Deze module kan gebruikt worden om bezoekers te laten inloggen op de site.
Dit kan voor de hele site, maar ook per pagina.

Installatie
-----------

- Als inloggen voor de alle pagina's nodig is: laad de module dan automatisch in met `$config['autoload_modules'] = array('login');` in site/config/config.php
- Als inloggen alleen op enkele pagina's nodig is: laad de module dan alleen in op die pagina's `$config['autoload_modules_if'] = array( 'login'=>array('b_restricted'=>'true') );`

- Er wordt automatisch een `tbl_login_menu` aangemaakt met alle nodige pagina's erin:
- Je moet in het menu in ieder geval een pagina hebben met de module 'login.logout'.
- Een pagina met de module 'login.login' is niet noodzakelijk omdat die automatisch wordt getoond indien nodig.
- Als gebruikers zelf hun paswoord moeten kunnen resetten dan moet ergens in het menu een pagina bestaan met de module 'login.forgot_password'.
- Als gebruikers zichzelf moeten kunnen registreren dan moet ergens in het menu een pagina bestaan met de module 'login.register'.
- Als gebruikers hun gegevens zelf moeten kunnen aanpassen dan moet ergens in het menu een pagina bestaan met de module 'login.edit'.


@version 2.0.1

@author Jan den Besten

@package FlexyAdmin_login


packed files
------

- db/add_login_menu.sql
- site/config/login.php
- site/language/en/login_lang.php
- site/language/nl/login_lang.php
- site/libraries/login.php
- site/models/formaction_login.php
- site/models/formaction_login_edit.php
- site/views/login.php
- site/views/login/login.php
- site/views/login/main.php
- site/views/login/register.php

'flexyadmin_login.zip' is a flexyadmin module - packed at 30 jun 2016 11:12
www.flexyadmin.com