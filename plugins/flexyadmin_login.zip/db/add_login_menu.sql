
# Dump of table tbl_loginmenu
# ------------------------------------------------------------

DROP TABLE IF EXISTS `tbl_loginmenu`;

CREATE TABLE `tbl_loginmenu` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order` smallint(6) NOT NULL DEFAULT '0',
  `uri` varchar(100) NOT NULL,
  `str_title` varchar(255) NOT NULL DEFAULT '',
  `txt_text` text NOT NULL,
  `b_visible` tinyint(1) NOT NULL DEFAULT '0',
  `str_module` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `tbl_loginmenu` (`id`, `order`, `uri`, `str_title`, `txt_text`, `b_visible`, `str_module`)
VALUES
	(1,1,'login','login','',1,'login.login'),
	(2,2,'register','Register','',0,'login.register'),
	(3,3,'password','Password','',0,'login.forgot_password'),
	(4,4,'aanpassen','Aanpassen','',1,'login.edit'),
	(5,5,'loguit','loguit','',1,'login.logout');
  
  

