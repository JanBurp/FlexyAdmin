Breadcrumb
==========

Installatie
----------------

- Voeg in views/site.php de code `<div id="breadcrumb"><?=$modules['breadcrumb']?></div>` toe
- Laad de module altijd in: `$config['autoload_modules']=array('breadcrumb');`


@package default

@author Jan den Besten
 

packed files
------

- site/config/breadcrumb.php
- site/libraries/breadcrumb.php
- site/views/breadcrumb.php

'flexyadmin_breadcrumb.zip' is a flexyadmin module - packed at 06 feb 2015 13:02
www.flexyadmin.com