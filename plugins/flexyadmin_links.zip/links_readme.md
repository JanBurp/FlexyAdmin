Toont een lijst met links
=========================

De getoonde links komen uit de tabel Links (tbl_links)

Bestanden
----------------

- site/views/links.php - De view waarin de lijst met links terecht komen

Installatie
----------------

- Voeg de module 'links' toe aan een pagina.


@author Jan den Besten
	

packed files
------

- site/libraries/links.php
- site/views/links.php

'flexyadmin_links.zip' is a flexyadmin module - packed at 06 feb 2015 14:56
www.flexyadmin.com