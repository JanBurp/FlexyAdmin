<div id="twitter">
<h1 class="small">Twitter:</h1>

<!-- Hier komt de emded code die je hier kunt krijgen: https://twitter.com/settings/widgets -->
<!-- Aanpassingen zie: https://dev.twitter.com/docs/embedded-timelines -->
<!-- Meer aanpassingen kan met de jquery.styleTwitter.js plugin -->

<a class="twitter-timeline"  href="https://twitter.com/jan_db"  data-widget-id="316527795184467971"
height="260"
width=""
data-chrome="noheader nofooter noborders"
data-link-color="#cc0000">Tweets van @jan_db</a>
<script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0];if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src="//platform.twitter.com/widgets.js";fjs.parentNode.insertBefore(js,fjs);}}(document,"script","twitter-wjs");</script>

<!-- Embed code tot hier -->

</div>




