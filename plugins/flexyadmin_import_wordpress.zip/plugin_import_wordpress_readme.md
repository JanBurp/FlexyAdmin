Importeerd een Wordpress Blog

- Exporteer in een wordpress blog
- Start deze plugin
- Kies het XML bestand dat de wordpress export heeft gegenereerd
- NB Zorg voor een internet verbinding! De afbeeldingen worden ook gedownload.


@package default

@author Jan den Besten
 

packed files
------

- site/config/plugin_import_wordpress.php
- site/libraries/plugin_import_wordpress.php

'flexyadmin_plugin_import_wordpress.zip' is a flexyadmin plugin - packed at 19 feb 2015 16:24
www.flexyadmin.com