<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Importeerd een Wordpress Blog
 * 
 * - Exporteer in een wordpress blog
 * - Start deze plugin
 * - Kies het XML bestand dat de wordpress export heeft gegenereerd
 * - NB Zorg voor een internet verbinding! De afbeeldingen worden ook gedownload.
 *
 * @package default
 * @author Jan den Besten
 */


class Plugin_import_wordpress extends Plugin {

  public function __construct() {
    parent::__construct();
    $this->CI->load->library('form');
    $this->CI->load->library('upload');
    $this->CI->load->dbforge();
    $this->CI->load->dbutil();
  }

	public function _admin_api($args=NULL) {
    $this->add_message("Importing a wordpress XML export file.");
    
    $fields=array('file'=>array('type'=>'file'));
    $form = new Form();
    $form->set_data($fields);
    if ($form->validation()) {
      $tmpname=$_FILES['file']['tmp_name'];
      $xml=read_file($tmpname);
      $XMLarray=xml2array($xml);
      $this->importWPxml($XMLarray);
    }
    else {
      $this->add_message($form->render());
    }
    return $this->view('admin/plugins/plugin');
	}
  
  /**
   * Import XML->DB
   *
   * @param string $XML 
   * @return void
   * @author Jan den Besten
   */
  private function importWPxml($XML) {
    $XMLcontent=$XML['rss']['channel'];
    $import_items = $this->config('import_items');
    foreach ($import_items as $wp_key => $info) {

      switch ($wp_key) {
        case 'wp:author' :
        case 'wp:tag':
          $data=filter_by_key($XMLcontent,$wp_key);
          $data=$data[$wp_key];
          $this->wp_simple_import($data,$info);
          break;
          
        case 'item':
          $data=filter_by_key($XMLcontent,$wp_key);
          $data=$data[$wp_key];
          $this->wp_import_posts($data,$info);
          break;
          
      }

    }
  }


  private function wp_simple_import($XML,$info,$create=TRUE) {
    // prepare db
    $table=$info['table'];
    $fields=$info['fields'];
    if ($create) $this->_prepare_table($table,$fields);

    // import
    $data=$XML;
    // trace_($data);
    $count=0;
    foreach ($data as $item) {
      $set=array();
      foreach ($item as $wp_key => $wp_value) {
        if (isset($fields[$wp_key])) {
          if (!is_array($wp_value)) $set[$fields[$wp_key]] = $wp_value;
        }
      }
      if (!empty($set)) {
        $this->CI->db->set($set);
        $this->CI->db->insert($table);
        $count++;
      }
    }
    $this->add_message('<p>Created: "'.$table.'" and imported '.$count.' items.</p>');
  }
  
  
  
  private function wp_import_posts($XML,$info) {
    $info=$info['wp:post_type'];
    // per post-type
    foreach ($info as $post_type => $type_info) {
      // prepare db
      $table=$type_info['table'];
      $fields=$type_info['fields'];
      $this->_prepare_table($table,$fields);
      
      // import this post-type
      $data=$XML;
      $count=0;
      $comments=false;
      foreach ($data as $item) {
        if ($item['wp:post_type']==$post_type) {
          $set=array();
          foreach ($item as $wp_key => $wp_value) {
            if (isset($fields[$wp_key])) {
              if (!is_array($wp_value)) {
                // specials
                switch ($wp_key) {
                  case 'content:encoded':
                    $wp_value=$this->add_images($wp_value);
                    break;
                  case 'wp:status':
                    $wp_value=($wp_value=='publish');
                    break;
                }
                $set[$fields[$wp_key]] = $wp_value;
              }
            }
          }

          // comments?
          if (isset($item['wp:comment']) and isset($fields['wp:comment'])) {
            // one comment? => make it an array
            if (isset($item['wp:comment']['wp:comment_id'])) {
              $comment=$item['wp:comment'];
              $item['wp:comment']=array();
              $item['wp:comment'][0]=$comment; 
            }
            // post id
            $id=$set['id'];
            foreach ($item['wp:comment'] as $key => $value) {
              $item['wp:comment'][$key]['id_wp_post']=$id;
            }
            $this->wp_simple_import($item['wp:comment'],$fields['wp:comment'],!$comments);
            $comments=true;
          }
          
          if (!empty($set)) {
            $this->CI->db->set($set);
            $this->CI->db->insert($table);
            $count++;
          }
        }
      }
      
      $this->add_message('<p>Created: "'.$table.'" and imported '.$count.' items.</p>');
    }

  }
  
  
  private function _prepare_table($table,$fields,$delete=TRUE) {
    if ($delete) $this->CI->dbforge->drop_table($table);
    // add table & fields
    $forge_fields=$this->CI->dbutil->create_forge_fields($fields);
    $this->CI->dbforge->add_field($forge_fields);
    $this->CI->dbforge->add_key('id', TRUE);
    $this->CI->dbforge->create_table($table);
  }
  

  public function image_callback($matches) {
    $defaults=array('src'=>'','alt'=>'','title'=>'');
    $img=$matches[0];
    $attributes=xml2array($img);
    $attributes=$attributes['img_attr'];
    $attributes=array_merge($defaults,$attributes);
    // keep simple
    $attributes=array_keep_keys($attributes,array_keys($defaults));
    if (empty($attributes['alt'])) $attributes['alt']=$attributes['title'];
    if (empty($attributes['title'])) $attributes['title']=$attributes['alt'];
    // upload image
    $src=$attributes['src'];
    // first get the image
    $name=$this->CI->upload->download_and_add_file($src,'pictures','wp_');
    $newsrc=$this->CI->config->item('ASSETS').'pictures/'.$name;
    $attributes['src']=$newsrc;
    $newimg='<img ';
    foreach ($attributes as $key => $value) {
      $newimg.=' '.$key.'="'.$value.'"';
    }
    $newimg.='/>';
    return $newimg;
  }
  private function add_images($txt) {
    $txt = preg_replace_callback("/<img([^>]*)\/>/uiUsm", array($this,'image_callback'), $txt);
    return $txt;
  }
  
  
  private function get_uri($url) {
    $url=trim($url,'/');
    $uris=explode('/',$url);
    return $uris[count($uris)-1];
  }

	
}

?>