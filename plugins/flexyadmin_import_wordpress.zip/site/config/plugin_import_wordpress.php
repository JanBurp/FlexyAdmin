<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Plugin methods:
| Set the names of the methods you use when FlexyAdmin want to call you
| If empty or commented, FlexyAdmin doesn't call them.
|--------------------------------------------------------------------------
|
*/

$config['admin_api_method'] = '_admin_api';

/**
 * Import tables
 */
$config['import_items'] = array(

  'wp:author'               => array(
    'table'                 => 'tbl_wp_authors',
    'fields'                => array(
      'wp:author_id'           => 'id',
      'wp:author_login'        => 'str_username',
      'wp:author_email'        => 'email_email',
      'wp:author_display_name' => 'str_display_name',
      'wp:author_first_name'   => 'str_first_name',
      'wp:author_last_name'    => 'str_last_name'
    ),
  ),
  
  'wp:tag'      => array(
    'table' => 'tbl_wp_tags',
    'fields' => array(
      'wp:term_id' => 'id',
      'wp:tag_slug' => 'uri',
      'wp:tag_name' => 'str_tag'
    )
  ),

  'item' => array(
    'wp:post_type' => array(
      'post' => array(
        'table'   => 'tbl_wp_posts',
        'fields'  => array(
      		'wp:post_id'      => 'id', 
      		'wp:post_name'    => 'uri',
      		'title'           => 'str_title',
      		'wp:post_date'    => 'tme_date',
          // 'category'        => 'str_category',
          'dc:creator'      => 'str_author',
      		'content:encoded' => 'txt_text',
      		'excerpt:encoded' => 'txt_intro',
      		'description'     => 'stx_description',
      		'link'            => 'url_old_link',
      		'wp:status'       => 'b_visible',
          'wp:comment'      => array(
            'table'   => 'tbl_wp_comments',
            'fields'  => array(
        			'wp:comment_id' => 'id',
              'id_wp_post'    => 'id_wp_post',
        			'wp:comment_author' => 'str_name',
        			'wp:comment_author_email' => 'email_email',
        			'wp:comment_author_url' => 'url_site',
        			'wp:comment_date' => 'tme_date',
        			'wp:comment_content' => 'txt_text',
        			'wp:comment_approved' => 'b_visible',
            )
          )
        ), // fields
      ),
      'page' => array(
        'table'           => 'tbl_wp_pages',
        'fields'          => array(
      		'wp:post_id'      => 'id', 
      		'wp:post_name'    => 'uri',
      		'title'           => 'str_title',
      		'wp:post_date'    => 'tme_date',
          // 'category'        => 'str_category',
          'dc:creator'      => 'str_author',
      		'content:encoded' => 'txt_text',
      		'excerpt:encoded' => 'txt_intro',
      		'description'     => 'stx_description',
      		'link'            => 'url_old_link',
      		'wp:status'       => 'b_visible',
        ),
      ) // page
    ) // post_type
  ) // item

);

?>
