<table width="400" cellspacing="0" cellpadding="10">
  <tr><th>Nieuwe reactie op {str_title}.</th></tr>
  <tr>
    <td>
      <a href="{url_link}"><h1>{str_article_title}</h1></a>
      <p>
        <b>{str_name}</b><br>
        <i>{tme_date}</i><br>
        {txt_text}
      </p>
    </td>
  </tr>
  <tr><th><a href="{url_url}">{str_title}</a></th></tr>
</table>