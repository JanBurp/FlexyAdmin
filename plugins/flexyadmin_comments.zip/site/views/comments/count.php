<div id="comments_count"><p><?=$text?>: <?=$count?></p></div>
