<div id="comments">

	<div id="comment_form"><?=$form?></div>

	<? foreach($items as $item): ?>
  <hr>
	<div id="comment_<?=$item['id']?>" class="comment">
		<p class="name"><?=$item['str_name']?></p>
		<p class="date"><?=$item['niceDate']?></p>
		<p><?=$item['txt_text']?></p>
	</div>
<? endforeach; ?>

</div>
