<?php

$lang['comments_title']='Jouw reactie';
$lang['comments_submit']='Reageer';
$lang['comments_count']='Aantal reacties';

// Voor elk veld in de tabel kun je de naam aanpassen:
$lang['str_name']='Naam';
$lang['email_email']='Email';
$lang['str_title']='Titel';
$lang['txt_text']='Reactie';

$lang['comments_mail_subject']='Nieuwe reactie op {str_title}';

?>