<?php

$lang['comments_title']='Comments';
$lang['comments_submit']='Place comments';
$lang['comments_count']='Number of comments';

// for each field you can give an alternative label text:
$lang['str_name']='Name';
$lang['email_email']='Email';
$lang['str_title']='Title';
$lang['txt_text']='Comment';

$lang['comments_mail_subject']='New comment on {str_title}';

?>