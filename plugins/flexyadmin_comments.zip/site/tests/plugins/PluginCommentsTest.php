<?php

class PluginCommentsTest extends CIUnit_Framework_TestCase {

  private $settings;

  protected function setUp () {
    $this->CI->load->helper('language');
    
    $this->CI->load->model('formaction');
    $this->CI->load->model('formaction_comments');
    
    $this->CI->config->load('comments',true);
    $this->settings=$this->CI->config->item('comments');
    
    $this->CI->site=$this->CI->db->get_row('tbl_site');
  }
  
  

  /**
   * Test formactions
   *
   * @return void
   * @author Jan den Besten
   */
  public function test_add_comment()  {
    // random item to connect comment with
    $table=foreign_table_from_key( $this->settings['key_id'] );
    $id=$this->CI->db->get_random_field($table);
    $this->settings['id']=$id;
    $this->settings['spam_rapport']['score']=rand(1,10);
    
    // init comment
    $this->CI->formaction_comments->initialize($this->settings);
    // random data
    $fields=$this->CI->formaction_comments->get_fields();
    $data=$this->CI->db->random_data($fields);
    $result=$this->CI->formaction_comments->go($data);

    $this->assertGreaterThanOrEqual(1,$result, 'Formaction_comments did not give success as result.');

  }

}

?>