#
# TABLE STRUCTURE FOR: tbl_comments
#

DROP TABLE IF EXISTS tbl_comments;

CREATE TABLE `tbl_comments` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_blog` int(11) NOT NULL,
  `tme_date` datetime NOT NULL,
  `str_name` varchar(255) NOT NULL DEFAULT '',
  `email_email` varchar(255) NOT NULL,
  `txt_text` text NOT NULL,
  `int_spamscore` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=utf8;

