<div class="shop-intro">
  <?php foreach($items as $name=>$item): ?>
    <div class="shop-intro-item">
      <h2><?=$item['str_title']?></h2>
      <?=$item['txt_text']?>
      <p class="shop-amount"><?=$item['amount']?><p>
      <a class="shop-intro-link-<?=$name?>" href="_api/shop_start?service=<?=$name?>">Pay</a>
    </div>
  <?php endforeach; ?>
</div>