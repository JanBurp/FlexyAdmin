<html>
  <head>
    <title>Dummy payment</title>
  </head>
  <style>
    body {background-color:#666;}
    .container {width:300px;margin:auto;}
    h1 {color:#FFF;}
    form {background-color:#FFF;padding:20px;width:200px;}
    input {width:100%;border:solid 1px #000;padding:4px;}
    input:hover {border-color:#F00;}
  </style>
<body>

<div class="container">
  <h1>Dummy payment</h1>

  <form action="<?=$action?>" id="dummy_payment" method="post" accept-charset="utf-8">
    <input type="hidden" name="reference" value="<?=$reference?>" />
    <input name="payed" value="<?=$amount?>"  />
    <br><br>
    <input type="submit" name="submit" value="START"  class="button" />
  </form>
</div>

</body>
</html>
