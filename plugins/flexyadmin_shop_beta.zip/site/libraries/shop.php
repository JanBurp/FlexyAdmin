<?php 

/**
 * The base for the shop plugin
 *
 * @package default
 * @author Jan den Besten
 */
class Shop extends Module {

}

?>