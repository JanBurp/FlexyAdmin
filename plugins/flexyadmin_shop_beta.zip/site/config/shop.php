<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Output routing of module
|--------------------------------------------------------------------------
|
| Stel hier in wat er met de return waarden van de module (methods) moet gebeuren:
|
| - Als er niets staat wordt het aan de pagina teruggegeven (zelfde als 'page')
| - 'page' - geeft de returnwaarde terug aan de pagina ($page)
| - 'site' - geeft de returnwaarde aan $this->site[module_naam.method]
| - Een combinatie is ook mogelijk, gescheiden door een pipe: 'page|site'
*/

// $config['__return']='';
// $config['__return.other']='site';
// $config['__return.other']='site|page';

// All files for the shop plugin
$config['_files'] = array(
  'db/shop.sql',
  'site/models/api/Shop*',
  'site/models/shop/*',
  'site/views/shop/*',
  'site/tests/shop/*',
);



// TESTMODE
$config['testmode'] = TRUE;


// Welk model en welke pagina verzorgen de afronding van de betaling:
$config['ready_url']    = find_module_uri('shop');
$config['ready_model'] = 'shop.payment_ready';

// Instellingen voor facturen
$config['invoice_path']     = 'invoices';   // Map waar de facturen in worden bewaard
$config['invoice_template'] = 'invoice';    // mail template in cfg_emails (subject wordt de bestandsnaam, email de factuur zelf)

// Instellingen voor betaling
$config['currency']     = 'euro';
$config['description']  = 'FlexyAdmin #{order_id} ';      // Beschrijving die consument op zijn/haar afschrift ziet.

// Berichtgeving aan eind van betaling en op factuur
$config['payment_message']  = '<p>Betaal via  {str_name} #{id}.</p>';
$config['messages']    = array(
  'SUCCESS'            => '<h2>Payment is completed.</h2><p>An email with invoice is on its way.</p>',
  'PENDING'            => '<h2>Your order will be completed after payment.</h2><p>An email with invoice and payment options is on its way.</p>',
  'FAILED'             => '<h2>Payment has failed, your order will be completed after payment.</h2><p>An email with invoice and payment options is on its way.</p>',
  'ERROR'              => '<h2>Payment has failed, your order will be completed after payment.</h2><p>An email with invoice and payment options is on its way.</p>',
);
$config['invoice_messages']  = array(
  'SUCCESS'            => '<p>Payment are completed.</p>',
  'PENDING'            => '<p>Your order will be completed after payment.</p>' . $config['payment_message'],
  'FAILED'             => '<p>Payment has failed, your order will be completed after payment.</p>' . $config['payment_message'],
  'ERROR'              => '<p>Payment has failed, your order will be completed after payment.</p>' . $config['payment_message'],
);


// Instellingen voor tabel met orders
$config['order_table']              = 'tbl_products';
$config['order_table_payed_field']  = 'b_payed';



/**
 * Payment services
 */
$config['services'] = array(

  // Dummy service, just for testing
  'dummy' => array(
    'model' => 'Dummy',
    'description'     => $config['description'],
    'intro' => array(
      'str_title' => 'Dummy TEST payment',
      'txt_text'  => '<p>This is a TEST payment, just for testing the payment process.</p>'
    )
  ),
  
  // Bank transfer
  'bank_transfer' => array(
    'model' => 'Bank_transfer',
    'description'     => $config['description'],
    'intro' => array(
      'str_title' => 'Bank transfer',
      'txt_text'  => '<p>Pay with a bank transfer.</p>'
    )
  ),
  
  // Mollie www.mollie.nl
  'mollie_ideal'     => array(
    'model'          => 'Mollie',
    'payment_method' => 'ideal',
    'intro'          => array(
      'str_title'    => 'iDEAL',
      'txt_text'     => '<p>Pay online with iDEAL.</p>'
    ),
    'test_mode'       => $config['testmode'],
    'description'     => $config['description'],
    'api_key_test'    => '',
    'api_key_live'    => '',
  ),

  // 'mollie_creditcard' => array(
  //   'model'          => 'Mollie',
  //   'payment_method' => 'creditcard',
  //   'intro' => array(
  //     'str_title' => 'CreditCard',
  //     'txt_text'  => '<p>Pay online with Creditcard.<br>Paying with CreditCard will increase the amount by 2.8%.</p>'
  //   ),
  //   'price_adjust'=> 1.028,
  //   'test_mode'   => $config['testmode'],
  //   'description' => $config['description'],
  //   'api_key_test'=> 'test_qQGtcQBwkHcE2drgkD8LRvFufwPJZ2',
  //   'api_key_live'=> 'live_BAeV4U72Ga4DjWVunXBQVeLksp4Anv',
  // ),


  
);
