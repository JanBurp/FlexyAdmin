<?php

/**
 * Return entry voor bank transfer
 * 
 * @author: Jan den Besten
 * $Revision: 3214 $
 * @copyright: (c) Jan den Besten
 */

class Shop_return_bank_transfer extends CI_Model {
  
	public function __construct() {
		parent::__construct();
    $this->load->model('shop/payment','payment');
    $this->payment->set_service('bank_transfer');
	}

  
  public function index() {
    return $this->payment->ready();
  }

}


?>
