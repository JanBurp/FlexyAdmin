<?php

/**
 * Retport / Hook entry voor webshops
 * 
 * @author: Jan den Besten
 * $Revision: 3214 $
 * @copyright: (c) Jan den Besten
 */

class Shop_report_dummy extends CI_Model {
  
	public function __construct() {
		parent::__construct();
    $this->load->model('shop/payment','payment');
    $this->payment->set_service('dummy');
	}

  
  public function index() {
    return $this->payment->report();
  }

}


?>
