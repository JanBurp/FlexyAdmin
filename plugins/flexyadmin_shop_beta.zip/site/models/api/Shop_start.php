<?php

/**
 * Shop start
 * 
 * @author: Jan den Besten
 * $Revision: 3214 $
 * @copyright: (c) Jan den Besten
 */

class Shop_start extends CI_Model {
  
	public function __construct() {
		parent::__construct();
    $this->load->library('session');
    $service = $this->input->get('service');
    $this->load->model('shop/payment','payment');
    $this->payment->set_service($service);
    log_message('INFO', '[_api/shop_start] - '.$service);
	}

  public function index() {
    $shop_data=$this->session->userdata('shop');
    return $this->payment->start( $shop_data['order_id'], $shop_data['amount'] );
  }

}


?>
