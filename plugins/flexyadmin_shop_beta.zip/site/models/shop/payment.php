<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Model dat betalingen doet doormiddel van de ingestelde betaalservice.
 * Bevat methods die in de database de betalingen bij kan houden.
 * 
 * SUCCESS, PENDING, CANCELLED, EXPIRED of FAILED
 *
 * @package default
 * @author Jan den Besten
 */

class Payment extends CI_Model {
  
  private $table                    = 'tbl_shop_transactions';
  private $order_key                = '';
  private $order_table              = '';
  private $order_table_payed_field  = '';
  
  
  /**
   * De gekozen betaal service en de instellingen daarvan
   */
  private $services = array();
  private $service  = '';
  
  /**
   * Gegenereerde reference
   */
  private $reference;
   

  public function __construct() {
    parent::__construct();
    $this->load->library('session');

    // Load config
    $this->config->load('shop',true);

    // Stel order tabel & key in
    $this->order_table             = $this->config->item('order_table','shop');
    $this->order_key               = foreign_key_from_table($this->order_table);
    $this->order_table_payed_field = $this->config->item('order_table_payed_field','shop');

    // Laad de services in
    $this->services = $this->config->item('services','shop');
    if (!is_array($this->services)) {
      log_message('ERROR', '[Payment.__construct] - no services set');
    }
    else {
      foreach ($this->services as $name => $service) {
        $this->services[$name]['name']=$name;
      }
    }
  }
  
  
  /**
   * Set payment service to use and returns its settings
   *
   * @param string $name 
   * @return array
   * @author Jan den Besten
   */
  public function set_service($name) {
    $this->service = $name;
    $model=$this->services[$name]['model'];
    // Laad service
    $this->load->model('shop/payment/Service');
    $this->load->unload_model('payment_service'); // for testing or using another service in one go
    $this->load->model('shop/payment/'.strtolower($model).'/'.$model, 'payment_service');
    // Init service
    $this->services[$name]['name']=$name;
    $this->payment_service->init($this->services[$name]);
    log_message('INFO', '[Payment.set_service - service loaded] - '.$name);
    return $this->services[$name];
  }


  /**
   * Maakt een unieke reference id aan
   *
   * @param string $order_id 
   * @return string
   * @author Jan den Besten
   */
  public function create_reference($order_id) {
    return $order_id. '_'. str_replace('.','_',microtime(true));
  }
  
  /**
   * Geeft reference terug
   *
   * @return void
   * @author Jan den Besten
   */
  public function get_reference() {
    return $this->reference;
  }
  
  
  /**
   * Laat alle betaalopties zien met hun intro
   *
   * @return void
   * @author Jan den Besten
   */
  public function intro($order_id,$amount) {
    // Remember $order_id & $amount
    $this->session->set_userdata('shop', array('order_id'=>$order_id,'amount'=>$amount) );
    // Show payment services
    $services=$this->config->item('services','shop');
    $items=array();
    $default = array(
      'str_title' => 'Name of payment service',
      'txt_text'  => 'Intro text of payment service',
    );
    foreach ($services as $name => $service) {
      $items[$name]             = array_merge($default,$service['intro']);
      $items[$name]['amount']  = $amount;
      if (isset($service['price_adjust'])) $items[$name]['amount'] = $amount * $service['price_adjust'];
      $items[$name]['amount'] = money_format('&euro; %i',$items[$name]['amount']);
    }
    return $this->load->view('shop/intro',array('items'=>$items),true);
  }
  
  
  /**
   * Start de betaling
   * - roept de service.start
   * - geeft html terug voor de bezoeker om een keus te maken in betaling
   *
   * @param string $order_id 
   * @param string $amount 
   * @return html
   * @author Jan den Besten
   */
  public function start($order_id,$amount) {
    $service=$this->services[$this->service];
    if (isset($service['price_adjust'])) $amount = $amount * $service['price_adjust'];
    
    // Betaling wel zinvol?
    if ($amount<=0) {
      $this->error=true;
      $this->response='<h1>Foutmelding</h1><p class="error"">Te laag bedrag voor een betaling.</p>';
      log_message('ERROR', '[Payment.start] Bedrag = 0 - order_id: '.$order_id.', amount: '.$amount);
      return $this->response;
    }
    // SSL?
    if (!$this->_has_ssl()) {
      $this->error=true;
      $this->response='<h1>Foutmelding</h1><p class="error"">Uw PHP installatie heeft geen SSL ondersteuning. SSL is nodig voor de communicatie met de betaalservice.</p>';
      log_message('ERROR', '[Payment.start] GEEN SSL verbinding... - order_id: '.$order_id.', amount: '.$amount);
      return $this->response;
    }
    
    // Betaling is zinvol, maak reference
    $this->reference=$this->create_reference($order_id);
    
    // Maak betaling aan in database
    $this->start_transaction($this->reference,$order_id,$amount);

    // Pas description aan
    $data=array(
      'order_id'  => $order_id,
      'amount'    => $amount,
      'reference' => $this->reference
    );
    $this->load->library('parser');
    $description = $this->payment_service->get('description');
    $description = $this->parser->parse_string($description, $data, TRUE);
    $this->payment_service->set('description',$description);
    
    // Roep service aan en geef html terug
    log_message('INFO', '[Payment.start] - order_id: '.$order_id.', amount: '.$amount.', reference: '.$this->reference);
    return $this->payment_service->start($this->reference,$order_id,$amount);
  }
  
  
  
  /**
   * Roept de report actie aan van de betaalservice
   *
   * @return void
   * @author Jan den Besten
   */
  public function report() {
    log_message('INFO', '[Payment.report_url] - ');
    return $this->payment_service->report();
  }

  
  /**
   * Roept de laatste actie aan van de betaalservice en komt terug met scherm naar de gebruiker
   *
   * @return html
   * @author Jan den Besten
   */
  public function ready() {
    $result=$this->payment_service->ready();
    
    if (!is_array($result) or !isset($result['reference'])) {
      $result['status']='ERROR';
    }
    else {
      $result['status'] = $this->check_transaction_status( $result['reference'] );
    }
    $status=el('status',$result,'ERROR');
    if (empty($status)) $status='ERROR';
    
    log_message('DEBUG', '[Payment.return_url] - status = '.$status);
    
    // Melding
    $messages=$this->config->item('messages','shop');
    $result['html'] = el($status,$messages,'ERROR');
    $messages=$this->config->item('invoice_messages','shop');
    $result['invoice_message'] = el($status,$messages,'ERROR');
    
    // Ga naar afronding
    $ready_url=$this->config->item('ready_url','shop');
    $ready_model=$this->config->item('ready_model','shop');
    
    // Roep method aan die betaling afrond
    if ($ready_model) {
			$model=remove_suffix($ready_model,'.');
			$method=get_suffix($ready_model,'.');
			if ($method==$model) $method='index';
      $this->load->model($model,'ready_model');
      $this->ready_model->$method($result);
    }
    
    // Ga naar ready_url
    if ($ready_url and !defined('PHPUNIT_TEST')) {
      // trace_([$ready_url,$result]);
      redirect($ready_url);
    }
    
    return $result;
  }
  
  
  
  
  
  /**
   * Bewaar de betaling in de database.
   * Dit wordt aangeroepen in start.php van de desbetreffende betaalservice
   *
   * @param string $reference 
   * @param int $order_id 
   * @param int $amount 
   * @return int insert_id
   * @author Jan den Besten
   */
  public function start_transaction($reference,$order_id,$amount) {
    $this->db->set('str_reference', $reference);
    $this->db->set($this->order_key, $order_id);
    $this->db->set('dec_amount', $amount);
    $this->db->set('str_status', '');
    $this->db->set('str_info', '');
    $this->db->insert( $this->table );
    $insert_id=$this->db->insert_id();
    return $insert_id;
  }
  
  
  /**
   * Geeft de transactie terug uit de database
   *
   * @param string $reference 
   * @return array
   * @author Jan den Besten
   */
  public function get_transaction($reference) {
    $this->db->where('str_reference',$reference);
    return $this->db->get_row($this->table);
  }

  /**
   * Verwijden een transactie uit de database
   *
   * @param string $reference 
   * @return void
   * @author Jan den Besten
   */
  public function remove_transaction($reference) {
    $this->db->where('str_reference',$reference);
    $this->db->delete($this->table);
  }
  
  /**
   * Checkt de status van een betaling
   *
   * @param string $reference 
   * @return string $status
   * @author Jan den Besten
   */
  public function check_transaction_status($reference) {
    $this->db->select('str_status');
    $transaction = $this->get_transaction($reference);
    return el('str_status',$transaction);
  }
  
  /**
   * Checkt het bedrag van de betaling
   *
   * @param string $reference 
   * @return string $status
   * @author Jan den Besten
   */
  public function check_transaction_amount($reference) {
    $this->db->select('dec_amount');
    $transaction = $this->get_transaction($reference);
    return el('dec_amount',$transaction);
  }
  
  
  /**
   * Pas de status van een betaling aan.
   *
   * @param string $reference 
   * @param string $status 
   * @param string $info 
   * @return $status
   * @author Jan den Besten
   */
  public function set_transaction_status($reference, $status='', $info='' ) {
    $this->db->set('str_status',$status);
    $this->db->set('str_info',$info);
    $this->db->where('str_reference',$reference);
    $this->db->update($this->table);
    return $status;
  }
  
  
  /**
   * Pas de status van een betaling aan in de 
   *
   * @param string $reference 
   * @param string $payed 
   * @return void
   * @author Jan den Besten
   */
  public function set_order_payed($reference,$payed=true) {
    $order_id = $this->db->get_field_where( $this->table, $this->order_key, 'str_reference', $reference );
    $this->db->set( $this->order_table_payed_field, $payed );
    $this->db->where( PRIMARY_KEY, $order_id);
    $this->db->update( $this->order_table );
    return $this;
  }
  
  
  /**
   * Test of SSL verbinding
   *
   * @return void
   * @author Jan den Besten
   */
  private function _has_ssl() {
    return in_array('ssl', stream_get_transports());
  }

   
}
