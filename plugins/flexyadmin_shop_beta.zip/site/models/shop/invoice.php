<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Verzorgt de berekening van de prijzen en het aanmaken van de factuur
 * 
 * 
 * In een factuur komen de volgende gegegevens die gebruikt kunnen worden in de template:
 * - Een lijst met keys meegegeven met de `set_client()` methode.
 * - Alle keys uit tbl_site
 * - Enkele standaard keys:
 *  - {date}
 *  - {time}
 *  - {datetime}
 * - En alle berekende prijzen (producten, discounts, vats en totalen)
 *
 * @package default
 * @author Jan den Besten
 */

class Invoice extends CI_Model {
  
  private $precision = 4; // Calculate precision (digits after komma)

  /**
   * De parameters van de client. Als een key->value array. De keys kunnen worden gebruikt in de factuur
   */
  private $client = array();
  
  /**
   * Producten
   * 
   * array(
   *  'name'    => '',
   *  'amount'  => '', // [1] Aantal (als niet wordt meegegeven is het 1)
   *  'price'   => '', // [0] without vat
   *  'vat'     => '', // [0]
   * )
   */
  private $products = array();

  /**
   * Kortingen
   * 
   * array(
   *  'description'       => '', // Omschrijving van de korting
   *  'discount_perc'     => '', // Kortings percentage
   * )
   */
  // private $discounts = array(); TODO


  /**
   * Berekende prijzen
   * 
   * array(
   * 
   *  'products' => array(
   *    array(
   *      'name'        => '',
   *      'amount'      => '',
   *      'price_excl'  => '', // Totaal prijs van aantal producten * prijs
   *      'price_incl'  => '', // idem...
   *      'vat'         => '',
   *    )
   *    ...
   *  ),
   * 
   * 'discounts' => array(
   *    array(
   *      'description' => '',
   *      'discount'    => '',    // Berekende korting over het gehele bedrag
   *    )
   *    ...
   * ),
   * 
   * 'vats' => array(             // Alle opgetelde BTW tarieven
   *    array(
   *      'vat'     => '6',
   *      'total'   => '',
   *    )
   *    ...
   * ),
   * 
   * 'total'      => '',          // Totaal zonder kortingen en BTW
   * 'total_excl' => '',          // Totaal inclusief korting, zonder BTW
   * 'total_vat'  => '',          // Totaal BTW tarieven
   * 'total_incl' => '',          // Totaal inclusief korting en BTW
   * 'payed'      => 0,           // Betaalde bedrag
   * )
   */
  private $prices = array();
  private $payed  = 0;
  
  private $invoice = '';



  public function __construct() {
    $this->load->library('parser');
    $this->load->model('cfg_email');
    $this->load->library('html2pdf/html2pdf');
    // Load config
    $this->config->load('shop',true);
    parent::__construct();
  }

  
  /**
   * Stel client data in
   *
   * @param array $client 
   * @return this
   * @author Jan den Besten
   */
  public function set_client($client) {
    $this->client=$client;
    return $this;
  }
  
  
  /**
   * Voeg de producten in een keer toe
   *
   * @param array $products 
   * @return this
   * @author Jan den Besten
   */
  public function set_products($products) {
    $default=array(
     'name'    => '',
     'amount'  => 1,
     'price'   => 0.00,
     'vat'     => 0,
    );
    foreach ($products as $key => $product) {
      $products[$key]=array_merge($default,$product);
    }
    $this->products=$products;
    return $this;
  }
  
  /**
   * TODO: Voeg eventuele kortingen toe
   *
   * @param string $discounts 
   * @return this
   * @author Jan den Besten
   */
  // public function set_discounts($discounts) {
  //   $this->discounts=$discounts;
  //   return $this;
  // }
  
  
  /**
   * Stel betaalde bedrag in
   *
   * @param int $payed 
   * @return this
   * @author Jan den Besten
   */
  public function payed($payed) {
    $this->payed=$payed;
    return $this;
  }
  
  
  /**
   * Bereken alle prijzen en geef die terug als array
   *
   * @return array
   * @author Jan den Besten
   */
  public function calc() {
    $prices=array();

    // TOTALS
    $prices['total'] = 0;
    $prices['total_excl'] = 0;
    $prices['total_vat']  = 0;
    $prices['total_incl'] = 0;
    $prices['payed']      = $this->payed;
    
    // Add products & there prices
    $prices['products']=array();
    foreach ($this->products as $product) {
      
      $price_excl = round( $product['price'] * $product['amount'],      $this->precision );
      $vat        = round( $price_excl       * ($product['vat']/100),   $this->precision );
      
      $prices['products'][]=array(
        'name'        => $product['name'],
        'amount'      => $product['amount'],
        'price'       => $product['price'],
        'vat'         => $product['vat'],
        'price_excl'  => $price_excl,
        'price_vat'   => $vat,
        'price_incl'  => $price_excl + $vat,
      );
    }
    
    // Calc VATS's
    $prices['vats']=array();
    foreach ($prices['products'] as $product) {
      $vat=$product['vat'];
      if (!isset($prices['vats'][$vat])) $prices['vats'][$vat]=array('vat'=>$vat,'total'=>0);
      $prices['vats'][$vat]['total'] += $product['price_vat'];
    }
    foreach ($prices['vats'] as $vat) {
      $prices['total_vat'] += $vat['total'];
    }

    // TOTALS
    foreach ($prices['products'] as $product) {
      $prices['total']      += $product['price_excl'];
      $prices['total_excl'] += $product['price_excl'];
      $prices['total_incl'] += $product['price_incl'];
    }
    
    $this->prices=$prices;
    
    return $prices;
  }
  
  /**
   * Geeft berekende prijzen
   *
   * @return array
   * @author Jan den Besten
   */
  public function get_prices() {
    return $this->prices;
  }
  
  
  /**
   * Geeft alle prijzen, maar dan als geformatteerde string ( € ...,- )
   *
   * @return void
   * @author Jan den Besten
   */
  public function get_formatted_prices() {
    $prices=$this->prices;
    $prices=$this->_format_prices($prices);
    return $prices;
  }
  private function _format_prices($prices) {
    $price_keys=array('price','total','payed');
    foreach ($prices as $key => $value) {
      if (is_array($value)) {
        $prices[$key]=$this->_format_prices($value);
      }
      elseif ( in_array($key,$price_keys) or in_array(get_prefix($key,'_'),$price_keys) ) {
        switch ($this->config->item('currency','shop')) {
          case 'euro':
            $char='&euro;';
            if (defined('PHPUNIT_TEST')) $char='€';
            $prices[$key] = money_format($char.' %i',$value);
            break;
          default:
            $prices[$key] = money_format('%i',$value);
            break;
        }
      }
    }
    return $prices;
  }

  
  /**
   * Maak de invoice en geef de bestandsnaam (zonder pad) terug, of FALSE als er een error is.
   *
   * @param mixed $template [FALSE]
   * @return string
   * @author Jan den Besten
   */
  public function create_invoice($template=FALSE) {
    if (!$template) {
      $template = $this->config->item('invoice_template','shop');
      $template = $this->cfg_email->get_template( $template );
    }
    if ($template===false) {
      return false;
    }
    
    $data = $this->db->get_row('tbl_site');
    $data['date']     = date('Y-m-d');
    $data['datetime'] = date('Y-m-d-H-i');
    $data['time']     = date('H-i-s');
    $data = array_merge($data,$this->client);
    
    // Filename
    $file = $this->parser->parse_string( $template['subject'], $data,true);
    $file = remove_suffix($file,'.').'.pdf';
    $full_path = $this->config->item('ASSETS') . $this->config->item('invoice_path','shop') .'/'. $file;

    // Calculate prices and add them to data
    $this->calc();
    $prices=$this->get_formatted_prices();
    $data = array_merge($data,$prices);
    
    // Invoice
    $invoice = $this->parser->parse_string( $template['body'],$data,true);
    $this->invoice = $invoice;

    // Make it a pdf and save if
    if (!defined('PHPUNIT_TEST')) {
      $html2pdf = new HTML2PDF('P', 'A4', 'en');
      $html2pdf->writeHTML($invoice);
      $html2pdf->Output($full_path,'F');
    }

    return $file;
  }
  
  
  /**
   * Geeft gerenderde invoice terug
   *
   * @return string
   * @author Jan den Besten
   */
  public function get_invoice() {
    return $this->invoice;
  }
  
   
   
   
   
   
   

}
