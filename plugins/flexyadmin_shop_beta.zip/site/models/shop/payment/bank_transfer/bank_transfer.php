<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Bank_transfer service voor Payment
 *
 * @package default
 * @author Jan den Besten
 */

class Bank_transfer extends Service {

  public function __construct() {
    parent::__construct();
    // $this->reportURL = '_api/shop_report_bank_transfer';
    $this->returnURL = '_api/shop_return_bank_transfer';
  }

  

  /**
   * Spring meteen naar afronding van betaling -> betaling gebeurt tenslotte met bank overmaking
   *
   * @param string $reference 
   * @param string $order_id 
   * @param string $amount 
   * @return void
   * @author Jan den Besten
   */
  public function start($reference,$order_id,$amount) {
    $this->payment->set_transaction_status($reference,'PENDING','BANK TRANSFER');
    $this->payment->set_order_payed($reference, FALSE );
    $redirect=$this->returnURL.'?reference='.$reference;
    if (defined('PHPUNIT_TEST')) return $redirect;
    redirect($this->returnURL.'?reference='.$reference);
  }
  

  /**
   * Geef melding dat de betaling nog niet is gebeurd
   *
   * @return array('reference'=>'','payed'=>'','status'=>'')
   * @author Jan den Besten
   */
  public function ready() {
    $reference = $this->input->get('reference');
    $status    = $this->payment->check_transaction_status($reference);
    return array(
      'reference' => $reference,
      'payed'     => 0,
      'status'    => $status,
    );
  }
  
}
