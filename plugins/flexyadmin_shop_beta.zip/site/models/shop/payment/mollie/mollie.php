<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

require_once('API/Autoloader.php');

/**
 * Betaalservice voor Mollie API
 *
 * @package default
 * @author Jan den Besten
 */

class Mollie extends Service {
  
  public function __construct() {
    parent::__construct();
    $this->reportURL = '_api/shop_report_mollie';
    $this->returnURL = '_api/shop_return_mollie';
  }
  
  /**
   * Initialises Mollie
   *
   * @return void
   * @author Jan den Besten
   */
  private function init_Mollie() {
    $this->mollieAPI = new Mollie_API_Client;
    
    if ($this->settings['test_mode'])
      $api_key=$this->settings['api_key_test'];
    else
      $api_key=$this->settings['api_key_live'];
    
    $this->mollieAPI->setApiKey($api_key);
  }
  

  


  /**
   * Laat de lijst van betaalopties zien
   *
   * @param string $reference 
   * @param string $order_id 
   * @param string $amount 
   * @return void
   * @author Jan den Besten
   */
  public function start($reference,$order_id,$amount=0) {
    log_message('DEBUG', '[PAYMENT - Mollie API - Start]');
    try
    {
      $this->init_Mollie();
    	/*
    	 * Generate a unique order id for this example. It is important to include this unique attribute
    	 * in the redirectUrl (below) so a proper return page can be shown to the customer.
    	 */
      // $order_id = time();

    	/*
    	 * Determine the url parts to these example files.
    	 */
      $hook_url    = site_url($this->reportURL.'?name='.$this->settings['name']);                            // URL die Mollie aanvraagt (op de achtergrond) na de betaling om de status naar op te sturen
      $return_url  = site_url($this->returnURL.'?name='.$this->settings['name'].'&reference='.$reference);   // URL waarnaar de consument teruggestuurd wordt na de betaling

    	/*
    	 * Payment parameters:
    	 *   amount        Amount in EUROs. This example creates a € 27.50 payment.
    	 *   description   Description of the payment.
    	 *   redirectUrl   Redirect location. The customer will be redirected there after the payment.
    	 *   metadata      Custom metadata that is stored with the payment.
    	 */
      $config=array(
    		"amount"       => $amount,
    		"description"  => $this->settings['description'],
        "webhookUrl"   => $hook_url,
        "redirectUrl"  => $return_url,
    		"metadata"     => array( "order_id" => $order_id, 'reference' => $reference ),
      );
      if (isset($this->settings['payment_method'])) {
        switch ($this->settings['payment_method']) {
        	case "ideal"        : $config['method'] = Mollie_API_Object_Method::IDEAL; break;
        	case "paysafecard"  : $config['method'] = Mollie_API_Object_Method::PAYSAFECARD; break;
        	case "creditcard"   : $config['method'] = Mollie_API_Object_Method::CREDITCARD; break;
        	case "mistercash"   : $config['method'] = Mollie_API_Object_Method::MISTERCASH; break;
        	case "banktransfer" : $config['method'] = Mollie_API_Object_Method::BANKTRANSFER; break;
        	case "paypal"       : $config['method'] = Mollie_API_Object_Method::PAYPAL; break;
        	case "bitcoin"      : $config['method'] = Mollie_API_Object_Method::BITCOIN; break;
        }
      }
    	$payment = $this->mollieAPI->payments->create($config);
      
      
    	/*
    	 * Send the customer off to complete the payment.
    	 */
      redirect($payment->getPaymentUrl());
    }
    catch (Mollie_API_Exception $e)
    {
    	$html="API call failed: " . htmlspecialchars($e->getMessage());
    }
  
    return $html;
  }


  /**
   * Hook (report) van de betaling
   */
  public function report() {
    log_message('DEBUG', '[PAYMENT - Mollie API - HOOK]');
    try
    {
    	$this->init_Mollie();
      
    	/*
    	 * Retrieve the payment's current state.
    	 */
      $transaction    = $_POST["id"];
    	$payment        = $this->mollieAPI->payments->get($transaction);
    	$reference      = $payment->metadata->reference;
      $order_id       = $payment->metadata->order_id;
      $payed          = $payment->amount;
      if ($payment->status!="paid" and $payment->status!="paidout") $payed=0;

    	/*
    	 * Update the database.
    	 */
      $amount=$this->payment->check_transaction_amount($reference);

      $status='FAILED';
      if ($payment->status=='paid' or $payment->status=="paidout") {
        $status='SUCCESS';
        if ($payed<$amount)  $status='PENDING';
    	}
    	else {
        $status='PENDING';
    	}
      $this->payment->set_transaction_status($reference,$status,'MOLLIE payed '.$payed);
      $this->payment->set_order_payed($reference, ($status=='SUCCESS') );
      
      log_message('DEBUG', '[PAYMENT - Mollie API - HOOK] - transaction_id '.$transaction);
      log_message('DEBUG', '[PAYMENT - Mollie API - HOOK] - reference '.$reference);
      log_message('DEBUG', '[PAYMENT - Mollie API - HOOK] - order_id '.$order_id);
      log_message('DEBUG', '[PAYMENT - Mollie API - HOOK] - amount '.$payed);
      log_message('DEBUG', '[PAYMENT - Mollie API - HOOK] - payment->status "'.$payment->status.'"');
      log_message('DEBUG', '[PAYMENT - Mollie API - HOOK] - status "'.$status.'"');
    }
    catch (Mollie_API_Exception $e)
    {
      log_message('DEBUG', '[PAYMENT - Mollie API - HOOK] - API call failed: ' . htmlspecialchars($e->getMessage()));
    }
    
    header("HTTP/1.1 200 OK");
    return 'ok!';
  }
  
  
  /**
   * Rond betaling af door melding te doen va resultaat
   */
  public function ready () {
    
    $reference=$this->input->get('reference');

    $status=$this->payment->check_transaction_status($reference);
    $payed=0;
    if ($status==='SUCCESS') $payed = $this->payment->check_transaction_amount($reference);
    
    log_message('DEBUG', '[PAYMENT - Mollie API - READY] - reference '.$reference);
    log_message('DEBUG', '[PAYMENT - Mollie API - READY] - status '.$status);
    
    
    return array(
      'reference' => $reference,
      'payed'     => $payed,
      'status'    => $status,
    );
  }
  
}
