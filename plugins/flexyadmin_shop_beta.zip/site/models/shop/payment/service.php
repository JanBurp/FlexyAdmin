<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Basis voor alle betaalmethoden
 *
 * @package default
 * @author Jan den Besten
 */

class Service extends CI_Model {
  
  protected $response = '';
  protected $error    = false;
  
  protected $reportURL = '_api/shop_report';
  protected $returnURL = '_api/shop_return';

  protected $settings = FALSE;
  

  public function __construct() {
    parent::__construct();
  }
  
  
  /**
   * Laad de instellingen van een service
   *
   * @param string $settings 
   * @return this
   * @author Jan den Besten
   */
  public function init($settings) {
    $this->settings=$settings;
    return $this;
  }
  
  /**
   * Geeft een instelling terug
   *
   * @param string $setting 
   * @return void
   * @author Jan den Besten
   */
  public function get($setting) {
    return el($setting,$this->settings);
  }
  
  /**
   * Pas een instelling aan
   *
   * @param string $setting 
   * @param mixed $value 
   * @return mixed de aangepast waarde ($value)
   * @author Jan den Besten
   */
  public function set($setting,$value) {
    $this->settings[$setting]=$value;
    return $this->settings[$setting];
  }
  
  
  /**
   * Start de betaaloptie, kan een redirect doen of een html retun
   *
   * @return mixed
   * @author Jan den Besten
   */
  public function start($reference,$order_id,$amount) {
    return 'Service.Start - mostly a redirect to payment service';
  }

  /**
   * Voert de actie uit die de betaalservice aanroept zonder feedback in de browser.
   * Een report of hook.
   *
   * @return void
   * @author Jan den Besten
   */
  public function report() {
    return 'Service.report - mostly a server call without feedback to the browser';
  }

  /**
   * Eindscherm van de betaling. Hier wordt de betaling afgerond afhankelijk van de status.
   * Geeft een result array terug:
   * 
   * - reference - unieke id waarmee de betaling gevonden kan worden in de tabel met betaaltransacties
   * - payed     - bedrag dat is betaald
   * - status    - ['PENDING'|'SUCCESS'|'FAILED'|'ERROR']
   *
   * @return array('reference'=>'','payed'=>'','status'=>'')
   * @author Jan den Besten
   */
  public function ready() {
    return array('reference'=>FALSE, 'payed'=>0, 'status'=>'DEMO');
  }
  
  
}
