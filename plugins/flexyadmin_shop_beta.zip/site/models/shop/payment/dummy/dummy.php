<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * Dummy betaal service voor Payment
 *
 * @package default
 * @author Jan den Besten
 */

class Dummy extends Service {

  public function __construct() {
    parent::__construct();
    $this->reportURL = '_api/shop_report_dummy';
    $this->returnURL = '_api/shop_return_dummy';
  }

  /**
   * Laat een formulier zien waar het betaalde bedrag kan worden ingevoerd
   *
   * @param string $reference 
   * @param string $order_id 
   * @param string $amount 
   * @return void
   * @author Jan den Besten
   */
  public function start($reference,$order_id,$amount) {
    return $this->load->view('shop/dummy_start',array('action'=>site_url($this->reportURL),'reference'=>$reference,'amount'=>$amount),true);
  }

  
  /**
   * Test de POST data van dummy form en de status
   *
   * @return array
   * @author Jan den Besten
   */
  public function report() {
    $reference = $this->input->post('reference');
    $payed     = $this->input->post('payed');
    $status    = $this->payment->check_transaction_status($reference);
    $amount    = $this->payment->check_transaction_amount($reference);
    if (empty($status) or $status=='PENDING') {
      $status = 'PENDING';
      if ($payed<$amount) $status='FAILED';
      $this->payment->set_transaction_status($reference,$status,'DUMMY report_url');
    }

    $redirect=$this->returnURL.'?reference='.$reference.'&payed='.$payed;
    if (defined('PHPUNIT_TEST')) return $redirect;
    redirect($redirect);
  }
  


  /**
   * Test de GET data en geeft de status terug
   *
   * @return array('reference'=>'','payed'=>'','status'=>'')
   * @author Jan den Besten
   */
  public function ready() {
    $reference = $this->input->get('reference');
    $payed     = $this->input->get('payed');
    $amount    = $this->payment->check_transaction_amount($reference);
    $status = 'SUCCESS';
    if ($payed<$amount) $status='FAILED';
    $this->payment->set_transaction_status($reference,$status,'DUMMY payed '.$payed);
    $this->payment->set_order_payed($reference, ($status=='SUCCESS') );
    
    return array(
      'reference' => $reference,
      'payed'     => $payed,
      'status'    => $status,
    );
  }
  
}
