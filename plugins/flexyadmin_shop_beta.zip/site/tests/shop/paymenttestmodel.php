<?php

require_once('sys/flexyadmin/tests/CITestCase.php');


/**
 * Test of berekening van shop goed gaat
 */

class PaymentTestModel extends CITestCase {
  
  var $references = array();

  public function setUp() {
    $this->CI->load->model('shop/payment','payment');
  }
  
  public function tearDown() {
    // remove all test references
    foreach ($this->references as $reference) {
      $this->CI->payment->remove_transaction($reference);
    }
    // remove all DUMMY transactions
    // $this->CI->db->where('str_info','DUMMY');
    // $this->CI->db->delete('tbl_shop_transactions');
  }
  
  /**
   * Enkele tests die terugkomen
   */
  protected function _test_reference($reference,$order_id, $message='Refence niet in orde') {
    $this->assertInternalType( 'string', $reference,            $message);
    $this->assertStringStartsWith( $order_id.'_', $reference,   $message);
    $this->assertGreaterThanOrEqual( 8, strlen($reference),     $message);
  }
  protected function _test_transaction($transaction,$reference,$amount, $status='', $message='Transactie niet in orde') {
    $this->assertInternalType( 'array', $transaction );
    $this->assertArrayHasKey( 'id', $transaction );
    $this->assertArrayHasKey( 'str_reference', $transaction );
    $this->assertArrayHasKey( 'dec_amount', $transaction );
    $this->assertArrayHasKey( 'str_status', $transaction );
    $this->assertEquals( $reference, $transaction['str_reference'] );
    $this->assertEquals( $amount, $transaction['dec_amount'] );
    $this->assertEquals( $status, $transaction['str_status'] );
  }
  

}

?>