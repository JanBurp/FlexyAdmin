<?php

require_once('sys/flexyadmin/tests/CITestCase.php');

/**
 * Test of berekening van shop goed gaat
 */

class InvoiceTest extends CITestCase {

  var $client = array(
    'name'    => 'Test Client',
    'email'   => 'test@flexyadmin.com',
  );
  
  var $products = array(
    array(
      'name'    => 'Product 1',
      'price'   => 10.0,
      'amount'  => 3,
      'vat'     => 21,
    ),
    array(
      'name'    => 'Product 2',
      'price'   => 20.00,
      'vat'     => 6,
    ),
    array(
      'name'    => 'Product 3',
      'price'   => 25.00,
      'amount'  => 1,
      'vat'     => 0,
    ),
    array(
      'name'    => 'Product 4',
      'price'   => 100.00,
      'vat'     => 21,
    ),
  );
  
  var $template = array(
    'subject' => 'Test invoice from {url_url}',
    'body'    => '
{name} - {email}
Date: {date}

PRODUCTEN:

{products}
{name} - {amount} x {price} = {price_excl}
{/products}

TOTAAL excl {total_excl}
BTW         {total_vat}
------------------------ +
TOTAAL incl {total_incl}
');
  
  public function setUp() {
    $this->CI->load->model('shop/invoice','invoice');
  }


  public function test_calc() {
    $this->CI->invoice->set_client( $this->client );
    $this->CI->invoice->set_products( $this->products );
    $prices = $this->CI->invoice->calc();
    $this->assertInternalType( 'array', $prices );
    
    // Product prijzen
    $this->assertArrayHasKey( 'products', $prices );
    $this->assertCount( count($this->products), $prices['products'] );
    $this->assertEquals( 30, $prices['products'][0]['price_excl'] );
    $this->assertEquals( 36.30, $prices['products'][0]['price_incl'] );
    $this->assertEquals( 20, $prices['products'][1]['price_excl'] );
    $this->assertEquals( 21.20, $prices['products'][1]['price_incl'] );
    $this->assertEquals( 25, $prices['products'][2]['price_excl'] );
    $this->assertEquals( 25, $prices['products'][2]['price_incl'] );
    $this->assertEquals( 100, $prices['products'][3]['price_excl'] );
    $this->assertEquals( 121, $prices['products'][3]['price_incl'] );
    
    // BTW
    $this->assertArrayHasKey( 'vats', $prices );
    $this->assertCount( 3, $prices['vats'] );
    $this->assertEquals( 0, $prices['vats'][0]['total'] );
    $this->assertEquals( 1.20, $prices['vats'][6]['total'] );
    $this->assertEquals( 27.30, $prices['vats'][21]['total'] );
    
    // Totalen
    $this->assertArrayHasKey( 'total', $prices );
    $this->assertArrayHasKey( 'total_excl', $prices );
    $this->assertArrayHasKey( 'total_vat', $prices );
    $this->assertArrayHasKey( 'total_incl', $prices );
    $this->assertEquals( 175, $prices['total'] );
    $this->assertEquals( 175, $prices['total_excl'] );
    $this->assertEquals( 28.50, $prices['total_vat'] );
    $this->assertEquals( 203.50, $prices['total_incl'] );
  }


  public function test_invoice() {
    $file     = $this->CI->invoice->create_invoice($this->template);
    $invoice  = $this->CI->invoice->get_invoice();
    
    $this->assertInternalType( 'string', $file, 'Waarschijnlijk is de invoice-template niet gevonden in cfg_emails. Dat kan betekenen dat er geen goede database wordt gebruikt voor testen.' );
    $this->assertEquals( 'pdf', get_suffix($file,'.') );
    
    $this->assertInternalType( 'string', $invoice );
    $this->assertContains( 'PRODUCTEN', $invoice );
    $this->assertContains( 'Product 1', $invoice );
    $this->assertContains( 'Product 2', $invoice );
    $this->assertContains( 'Product 3 - 1 x € 25.00 = € 25.00', $invoice );
    $this->assertContains( 'TOTAAL excl € 175.00', $invoice );
  }
  

}

?>