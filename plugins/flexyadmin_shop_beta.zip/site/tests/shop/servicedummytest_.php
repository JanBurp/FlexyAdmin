<?php

require_once('PaymentTestModel.php');


class ServiceDummyTest extends PaymentTestModel {
  
  
  /**
   * Test de dummy betaal service
   */
  public function test_dummy_service() {
    // Stel de service in
    $service=$this->CI->payment->set_service('dummy');
    $this->assertInternalType( 'array', $service );
    $this->assertArrayHasKey( 'name', $service );
    $this->assertEquals( 'dummy', $service['name'] );

    // Start transactie via de service
    $order_id = rand(0,999);
    $amount = rand(1,999999)/10;
    $html = $this->CI->payment->start($order_id,$amount);

    // Is er een juist reference aangemaakt?
    $reference=$this->CI->payment->get_reference();
    $this->references[]=$reference;
    $this->_test_reference($reference, $order_id, 'test_dummy_service');

    // Test de gemaakte transaction
    $transaction = $this->CI->payment->get_transaction($reference);
    $this->_test_transaction($transaction,$reference,$amount,'', 'test_transactions');

    // Geeft de service.start HTML terug?
    $this->assertInternalType( 'string', $html);
    $this->assertContains( '<h1>Dummy payment</h1>', $html);
    $this->assertContains( '</form>', $html);

    // Test de dummy report_URL
    $_POST=array(
      'reference'=>$reference,
      'service'=>'dummy',
      'payed'=>$amount,
    );
    $report = $this->CI->payment->report();
    unset($_POST);
    $this->assertInternalType( 'string', $report );
    $this->assertContains( '_api/shop_return_dummy', $report );
    $this->assertEquals( '_api/shop_return_dummy?reference='.$reference.'&payed='.$amount, $report );

    $transaction = $this->CI->payment->get_transaction($reference);
    $this->assertInternalType( 'array', $transaction );
    $this->assertEquals( 'PENDING', $transaction['str_status'] );
    $this->assertEquals( 'DUMMY report_url', $transaction['str_info'] );

    // Test de dummy return_URL
    $_GET=array(
      'reference'=>$reference,
      'payed'=>$amount,
    );
    $return = $this->CI->payment->ready();
    $this->assertInternalType( 'array', $return );
    $this->assertArrayHasKey( 'reference', $return );
    $this->assertArrayHasKey( 'status', $return );
    $this->assertArrayHasKey( 'payed', $return );
    $this->assertArrayHasKey( 'html', $return );
    $this->assertEquals( 'SUCCESS', $return['status'] );

    // Test complete transactie
    $transaction = $this->CI->payment->get_transaction($reference);
    $this->assertInternalType( 'array', $transaction );
    $this->assertEquals( 'SUCCESS', $transaction['str_status'] );
    $this->assertContains( 'DUMMY', $transaction['str_info'] );
  }
 

}

?>