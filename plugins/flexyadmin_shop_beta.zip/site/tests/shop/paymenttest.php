<?php

require_once('PaymentTestModel.php');


/**
 * Test of berekening van shop goed gaat
 */

class PaymentTest extends PaymentTestModel {
  
  var $order_id;
  var $amount;
  
  
  /**
   * Test of de transacties en de database werkt
   */
  public function test_transactions() {
    // Test de aanmaak van aan reference
    $this->order_id = rand(0,999);
    $reference = $this->CI->payment->create_reference($this->order_id);
    $this->references[]=$reference;
    $this->_test_reference($reference,$this->order_id, 'test_transactions');
    
    // Start en test transactions
    $this->amount = rand(1,999999)/10;
    $this->CI->payment->start_transaction($reference,$this->order_id,$this->amount);
    $transaction = $this->CI->payment->get_transaction($reference);
    $this->_test_transaction($transaction,$reference,$this->amount,'', 'test_transactions');
    
    // Check status
    $status = $this->CI->payment->check_transaction_status($reference);
    $this->assertInternalType( 'string', $status );
    $this->assertEquals( '', $status );
    
    // Update and check status
    $this->CI->payment->set_transaction_status($reference,'TESTING');
    $status = $this->CI->payment->check_transaction_status($reference);
    $this->assertInternalType( 'string', $status );
    $this->assertEquals( 'TESTING', $status );
  }
  
  
  public function test_intro() {
    $intro=$this->CI->payment->intro( $this->order_id, rand(1,999999)/10 );
    
    $this->assertInternalType( 'string', $intro);
    $this->assertContains( '<div class="shop-intro">', $intro);
    $this->assertContains( '<div class="shop-intro-item">', $intro);
    // $this->assertContains( '<h2>Dummy TEST payment</h2>', $intro);
  }

}

?>