<?php

/**
 * START SELENIUM FIRST:
 * 
 * java -jar /usr/local/bin/selenium-server-standalone.jar
 * http://phpro.org/tutorials/Automated-Testing-With-Selenium2-And-PHPUnit.html
 *
 * @package default
 * @author Jan den Besten
 */


class BrowserTest extends PHPUnit_Extensions_Selenium2TestCase {

  protected function setUp() {
    $this->setBrowser('firefox');
    $this->setBrowserUrl('http://localhost/projecten_2014/www.foodcolloids2016.nl/');
    $this->prepareSession()->currentWindow()->maximize();
  }


  public function testForm() {
    $payments = array(
      // array('service'=>'dummy','amount'=>'0'),
      // array('service'=>'dummy','amount'=>'500'),
      // array('service'=>'dummy','amount'=>'550'),
      array('service'=>'bank_transfer'),
      // array('service'=>'mollie_ideal'),
    );
    
    foreach ($payments as $payment) {
      $this->url('registration/registration_conference');
      $this->assertEquals('16th Food Colloids Conference - Registration conference', $this->title());
      $fields                                = array(
        "str_family_name"                    => 'Tester',
        "str_given_name"                     => 'Jan',
        "email_email"                        => 'test@flexyadmin.com',
        "str_affiliation"                    => 'PHP Unit - Selenium '.date("j F Y, H:m:s") ,
        "str_address"                        => 'Ergens 13',
        "str_postal_code"                    => '1234AB',
        "str_city"                           => 'Daaro',
        "str_country"                        => 'NL',
        "str_registration_type"              => 'Full registration<br><small>(€ 550 until February 26th, thereafter € 650)</small>',
        // "b_participate_in_welcome_reception" => random_element(array('Yes','No')),
        // "b_participate_in_social_program"    => random_element(array('Yes','No')),
        // "b_participate_in_gala_dinner"       => random_element(array('Yes','No')),
      );

      // create a form object for reuse
      $form = $this->byId( 'registration' );

      // Fill elements and test them
      foreach ($fields as $name => $value) {
        $field = $this->byName( $name );
        $field->value( $value );
        $this->assertEquals( $value, $field->value() );
      }
      // Vul registration form
      $form->submit();

      sleep(3);
      
      switch ($payment['service']) {
        case 'dummy':
          $this->byCssSelector('a.shop-intro-link-dummy')->click();
          $field = $this->byName( 'payed' );
          $field->clear();
          $field->value( $payment['amount'] );
          $form=$this->byId( 'dummy_payment' );
          sleep(1);
          $form->submit();
          break;
          
        default:
          $this->byCssSelector('a.shop-intro-link-'.$payment['service'])->click();
          break;

      }

      sleep(2);
    }
  }
  
  
  public function screenshot() {
    $filedata = $this->currentScreenshot($file);
    file_put_contents('/Users/jan/Sites/screenshots/'.$file.date('d-M-Y__H:m:s').'.jpg', $filedata);
  }

}
?>
