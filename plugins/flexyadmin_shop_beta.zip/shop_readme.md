The base for the shop plugin


@package default

@author Jan den Besten
 

packed files
------

- db/shop.sql
- site/config/shop.php
- site/libraries/shop.php
- site/models/api/Shop_report_dummy.php
- site/models/api/Shop_report_mollie.php
- site/models/api/Shop_return_bank_transfer.php
- site/models/api/Shop_return_dummy.php
- site/models/api/Shop_return_mollie.php
- site/models/api/Shop_start.php
- site/models/shop/invoice.php
- site/models/shop/payment
- site/models/shop/payment.php
- site/models/shop/payment/bank_transfer
- site/models/shop/payment/bank_transfer/bank_transfer.php
- site/models/shop/payment/dummy
- site/models/shop/payment/dummy/dummy.php
- site/models/shop/payment/mollie
- site/models/shop/payment/mollie/api
- site/models/shop/payment/mollie/api/autoloader.php
- site/models/shop/payment/mollie/api/cacert.pem
- site/models/shop/payment/mollie/api/client.php
- site/models/shop/payment/mollie/api/exception.php
- site/models/shop/payment/mollie/api/object
- site/models/shop/payment/mollie/api/object/issuer.php
- site/models/shop/payment/mollie/api/object/list.php
- site/models/shop/payment/mollie/api/object/method.php
- site/models/shop/payment/mollie/api/object/payment
- site/models/shop/payment/mollie/api/object/payment.php
- site/models/shop/payment/mollie/api/object/payment/refund.php
- site/models/shop/payment/mollie/api/resource
- site/models/shop/payment/mollie/api/resource/base.php
- site/models/shop/payment/mollie/api/resource/issuers.php
- site/models/shop/payment/mollie/api/resource/methods.php
- site/models/shop/payment/mollie/api/resource/payments
- site/models/shop/payment/mollie/api/resource/payments.php
- site/models/shop/payment/mollie/api/resource/payments/refunds.php
- site/models/shop/payment/mollie/examples
- site/models/shop/payment/mollie/examples/1-new-payment.php
- site/models/shop/payment/mollie/examples/2-webhook-verification.php
- site/models/shop/payment/mollie/examples/3-return-page.php
- site/models/shop/payment/mollie/examples/4-ideal-payment.php
- site/models/shop/payment/mollie/examples/5-payments-history.php
- site/models/shop/payment/mollie/examples/6-list-activated-methods.php
- site/models/shop/payment/mollie/examples/7-refund-payment.php
- site/models/shop/payment/mollie/examples/initialize.php
- site/models/shop/payment/mollie/ideal.class.php
- site/models/shop/payment/mollie/mollie.php
- site/models/shop/payment/service.php
- site/tests/shop/browsertest.php
- site/tests/shop/invoicetest.php
- site/tests/shop/paymenttest.php
- site/tests/shop/paymenttestmodel.php
- site/tests/shop/servicebanktransfertest.php
- site/tests/shop/servicedummytest_.php
- site/views/shop/dummy_start.php
- site/views/shop/intro.php

'flexyadmin_shop.zip' is a flexyadmin module - packed at 08 jul 2015 12:39
www.flexyadmin.com