#
# Shop Plugin
#
# DATA TABLES: cfg_email
#

CREATE TABLE `tbl_products` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `str_product` varchar(255) NOT NULL,
  `dec_amount` decimal(7,2) NOT NULL,
  `b_payed` tinyint(1) NOT NULL DEFAULT '0',
  `media_invoice` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;


CREATE TABLE `tbl_shop_transactions` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `str_reference` varchar(255) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `id_registrations` int(11) NOT NULL,
  `dec_amount` decimal(8,2) NOT NULL,
  `str_status` varchar(20) CHARACTER SET utf8 NOT NULL DEFAULT '',
  `str_info` mediumtext CHARACTER SET utf8,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `str_payment_id` (`str_reference`)
) ENGINE=InnoDB AUTO_INCREMENT=0 DEFAULT CHARSET=latin1;