Nieuwsbrief

Samen met de bijbehorende plugin kan hiermee een nieuwsbrief functie aan de site worden gekoppeld.
Deze module verzorgt het aan en afmelden van bezoekers aan de nieuwsbrief.

Ook is aanmelding mogelijk met het terugmailen van een kado-bestand. Een zogenaamde 'optin'.

Bestanden
----------------

- db/add_newsletter.sql - database bestand met de benodigde tabel
- site/config/plugin_newsletter.php - Plugin voor het admin deel
- site/libraries/plugin_newsletter.php - Plugin voor het admin deel
- site/models/formaction_newsletter.php
- site/models/newsletter_model.php
- site/views/newsletter - De views en email templates
- site/language/##/newsletter_lang.php - Taalbestanden

Installatie
----------------

- Zorg ergens op je site voor een (un)submit formulier door de module newsletter te koppelen aan een pagina
- Stel in site/config/config.php: $config['query_urls']=TRUE;
- Newsletter wordt automatisch toegevoegd aan het Admin menu, zorg zelf nog even voor de juiste plaats


@author Jan den Besten

@package FlexyAdmin_newsletter

	

packed files
------

- db/add_newsletter.sql
- site/config/newsletter.php
- site/config/plugin_newsletter.php
- site/language/en/newsletter_lang.php
- site/language/nl/newsletter_lang.php
- site/libraries/newsletter.php
- site/libraries/plugin_newsletter.php
- site/models/formaction_newsletter.php
- site/models/newsletter_model.php
- site/views/newsletter/email_body.php
- site/views/newsletter/email_items.php
- site/views/newsletter/export.php
- site/views/newsletter/newsletter.php
- site/views/newsletter/newsletter_main.php

'flexyadmin_newsletter.zip' is a flexyadmin module - packed at 23 feb 2015 11:07
www.flexyadmin.com