<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/**
 * @package default
 * @author Jan den Besten
 */
 class Formaction_newsletter extends Formaction {

   var $settings = array();

   /**
    * @author Jan den Besten
    * @ignore
    */
   public function __construct() {
     parent::__construct();
     $this->load->model('newsletter_model');
   }
   
   
   public function fields() {
     $fields=$this->db->list_fields( $this->settings['address_table'] );
     $formFields=array2formfields($fields,array('str'=>'required|max_length[255]'));
     unset($formFields['id']);
     unset($formFields['tme_added']);
     unset($formFields['b_send']);
     return $formFields;
   }
   
   
   /**
    * (un)submit emailadres
    *
    * @param string $data data teruggekomen van het formulier
    * @return int id van toegevoegde data in de database
    * @author Jan den Besten
    * @ignore
    */
   public function go($data) {
     parent::go($data);
    
     switch ($this->form_id) {
       case 'submit_form':
         return $this->_submit($data);
         break;

       case 'unsubmit_form':
         return $this->_unsubmit($data);
         break;
      
       case 'optin_form':
         return $this->_optin($data);
         break;
     }
    
     return false;
   }
   
   
     
  /**
   * Submit
   *
   * @param string $data 
   * @return void
   * @author Jan den Besten
   */
  private function _submit($data) {
    $table=$this->settings['address_table'];
    $id=$this->newsletter_model->submit($data,$table);
    return $id;
  }


  /**
   * Unsubmit
   *
   * @param string $data 
   * @return void
   * @author Jan den Besten
   */
  private function _unsubmit($data) {
    $this->config->load('plugin_newsletter',TRUE);
    $this->newsletter_model->initialize($this->config->item('plugin_newsletter'));

    $table=$this->settings['address_table'];
    $code=$this->input->get('unsubmit');
    $id=$this->newsletter_model->find_id_by_unsubmit_email($code,$data['email_email']);
    if ($id) {
      $this->newsletter_model->unsubmit($id,$data,$table);
    }
    else {
      $this->add_error(lang('unsubmit_error'));
    }
    return $id;
  }
  
  
  
  private function _optin($data) {
    // Aanmelding
    $this->_submit($data);
    
    // Email verzenden
    $this->load->library('email');
    $email=$this->site['email_email'];

    // TO
    $this->email->to($data['email_email']);
    // FROM
    $this->email->from($email);
    // BCC
    $this->email->bcc($email);
    
    // SUBJECT - vervang keys
    $subject=$this->settings['subject'];
    $replace['/%URL%/uiUsm']=trim(str_replace('http://','',$this->site['url_url']),'/');
    $emailfields=filter_by_key($data,'email');
    if (empty($emailfields)) $emailfields=filter_by_key($data,'Email');
    if ($emailfields) $replace['/%MAIL%/uiUsm']=current($emailfields);
    foreach ($data as $key => $value) {
      $replace['/%'.$key.'%/uiUsm']=$value;
    }
    $subject = preg_replace(array_keys($replace),array_values($replace), $subject);
    $this->email->subject($subject);
    
    // BODY
    $body='';
    $this->email->message($body);
    $attachment='site/assets/downloads/'.$this->site[$this->settings['media_optin_field']];
    $this->email->attach($attachment);
    if (!$this->email->send()) {
      $this->errors=$this->email->print_debugger();
      return false;
    }
    
    return true;
  }
  
  
  
  
}
