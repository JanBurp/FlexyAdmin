<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Newsletter_model extends CI_Model {
  
  private $settings=array();
  private $rapport='';
  private $send_to=array();
  
  public function __construct() {
    parent::__construct();
    $this->load->library('parser');
    $this->load->library('email');
  }
  
  
  public function initialize($settings=array()) {
    if (empty($settings['unsubmit_uri'])) {
      $settings['unsubmit_uri']=find_module_uri('newsletter');
    }
    $this->settings=$settings;
    return $this;
  }
  
  
  public function create_automatic_email($type='default') {
    $data=$this->_get_replace_data();
    $email=array();
    $email['subject']=$this->settings['subject'];
    $email['subject']=$this->parser->parse_string($email['subject'],$data,true);
    $email['body']=$this->get_automatic_body($type);
    return $email;
  }
  
  public function get_automatic_body($type='default') {
    $data=$this->_get_replace_data();
    $content=el(['content',$type],$this->settings);
    $body='';
    if ($content) {
      foreach ($content as $name => $info) {
        $model=$info['model'];
        $method=get_suffix($model,'.');
        $model=get_prefix($model,'.');
        $this->load->model($model);
        $content[$name]['html']='';
        if (method_exists($model,$method)) {
          $items=$this->$model->$method();
          if ($items) {
            $content[$name]['items']=$items;
            $content[$name]['html']=$this->load->view($info['view'],array('items'=>$items),true);
          }
        }
      }
    }
    $body=$this->load->view('newsletter/email_body',array('content'=>$content),true);
    $body=$this->parser->parse_string($body,$data,true);
    $body=$this->_add_styles($body);
    return $body;
  }
  
  private function _get_replace_data() {
    $data=$this->db->get_row('tbl_site');
    $data['url']=str_replace(array('http://','https://'),'',$data['url_url']);
    $data['now']=strftime('%A %e %b %Y');
    return $data;
  }
  
  
  
  /**
   * Verstuur een mail
   *
   * @param string $mail 
   * @return void
   * @author Jan den Besten
   * @ignore
   */
  public function send_mail($mail) {
    if ($mail['body']===FALSE) return false;
    $this->rapport='<p>'.strftime('%a %d %b %Y %T',now()).' - ';
    
    $this->email->clear(TRUE);
    $mail['body']=$this->email->prepare_body($mail['body']);
    $this->send_to=array();
    $to=explode(',',$mail['to']);
    if (isset($mail['bcc'])){
      $bcc=explode(',',$mail['bcc']);
      unset($mail['bcc']);
    }
    
    // TEST?
    if ($this->settings['test']) {
      $mail['subject']='TEST '.$mail['subject'];
      $to=array_slice($to,0,3);
      if (isset($bcc)) $bcc=array_slice($bcc,0,3);
    }

    // TO
    foreach ($to as $to_one) {
      $this->_send_one($mail,$to_one);
    }
    // BCC
    if (isset($bcc)) {
      foreach ($bcc as $to_one) {
        $this->_send_one($mail,$to_one);
      }
    }
    $this->rapport.='Send to '.count($this->send_to).' email-address(es)<br/></p>';
    return $this->rapport;
  }
  private function _send_one($mail,$to_one) {
    $mail['to']=$to_one;
    $data=array('unsubmit_url'=>$this->settings['unsubmit_uri'].'?unsubmit='.$this->create_unsubmit_code($to_one));
    $mail['body']=$this->parser->parse_string($mail['body'],$data,true);
    $this->email->set_mail($mail);
    $send=$this->email->send();
    $this->email->clear(TRUE);
		if ($send)
			$this->send_to[]=$to_one;
		else {
      $this->rapport.='ERROR sending ('.$to_one.'), debug information:<br/>';
			$this->rapport.=$this->email->print_debugger();
    }
    $mail['to']='';
    return $send;
  }
  
  
  private function _add_styles($body) {
    $styles=$this->settings['styles'];
    return $this->email->add_styles($body,$styles);
  }
  
  
  
  /**
   * Haalt alle adressen op
   *
   * @return array
   * @author Jan den Besten
   * @ignore
   */
  public function get_adresses($check_send=true) {
    if ($check_send and $this->db->field_exists($this->settings['send_field'],$this->settings['address_table'])) {
      $this->db->where($this->settings['send_field'],true);
    }
    $adresses=$this->db->get_result( $this->settings['address_table'] );
    $to='';
		foreach ($adresses as $adres) {
      $mail=$adres[$this->settings['email_field']];
      $name=$adres[$this->settings['name_field']];
      if (empty($name))
        $a=$mail;
      else
        $a=$name.' <'.$mail.'>';
      $to=add_string($to,$a,', ');
    }
    return $to;
  }
  
  
  public function create_unsubmit_code($email) {
    $email=get_emails($email,TRUE);
    $id=$this->db->get_field_where($this->settings['address_table'],'id',$this->settings['email_field'],$email);
    $code=false;
    if ($id) $code=md5($id.$email);
    return $code;
  }
  
  public function find_id_by_unsubmit_email($code,$email) {
    $id=$this->db->get_field_where($this->settings['address_table'],'id',$this->settings['email_field'],$email);
    $found_code=md5($id.$email);
    if ($code==$found_code) return $id;
    return false;
  }
  
  
  public function unsubmit($id,$data,$table='tbl_newsletter_addresses') {
    $this->db->set($this->settings['send_field'],false);
    $this->db->where('id',$id)->where('email_email',$data['email_email']);
    $this->db->update($table);
    return $id;
  }
  
  
  public function submit($data,$table='tbl_newsletter_addresses') {
    // Bestaat dit emailadres al? Dan niet aanmelden, maar activeren en datum updaten
    $id=FALSE;
    if ($item=$this->db->has_row($table,array('email_email'=>$data['email_email']))) {
      $id=$item['id'];
    }
    // tme_ of dat_ veld toevoegen
    $fields=$this->db->list_fields($table);
    $fields=array_values($fields);
    $date_fields=array();
    foreach ($fields as $key => $field) {
      if (in_array(get_prefix($field),$this->config->item('FIELDS_date_fields'))) $date_fields[]=$field;
    }
    foreach ($date_fields as $field) {
      if (!isset($data[$field]) or $data[$field]=='') $data[$field]=unix_to_mysql();
    }
    // b_send standaard aan
    $data['b_send'] = true;
    // set
    foreach ($data as $key => $value) {
      if ($this->db->field_exists( $key, $table )) $this->db->set($key,$value);
    }
    // insert in db
    if (!$id) {
      $this->db->insert( $table );
      $id=$this->db->insert_id();
    }
    // update
    else {
      $this->db->where('id',$id);
      $this->db->update($table);
    }
    return $id;
  }
  
  
}
