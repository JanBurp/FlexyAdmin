<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Plugin methods:
| Set the names of the methods you use when FlexyAdmin want to call you
| If empty or commented, FlexyAdmin doesn't call them.
|--------------------------------------------------------------------------
|
*/

$config['admin_api_method'] = '_admin_api';


/*
|--------------------------------------------------------------------------
| Plugins specific config settings
|--------------------------------------------------------------------------
|
*/

$config['test']               = FALSE; // if true, sends max 3 emails and in subject the word TEST is added

$config['from']               = 'no-reply@flexyadmin.com';

// Unsubmit url
$config['unsubmit_uri']       = ''; // als leeg, dan wordt automatisch gezocht naar de pagina met de module newsletter.unsubmit

// Subject
$config['subject']            = 'NIEUWSBRIEF - {url} - {now}';


// Geef hier de models en views waar de automatische inhoud vandaan moet komen
$config['content']['default'] = array(
  // 'tbl_agenda'    => array(
  //   'model'     => 'agenda_model.get_newsletter',
  //   'view'      => 'newsletter/email_items',
  // ),
  // 'tbl_artikelen' => array(
  //   'model'     => 'artikelen.get_newsletter',
  //   'view'      => 'newsletter/email_items',
  // )
);

// Voeg deze inline styles toe aan bepaalde html tags in de email
$config['styles'] = array(
  'table'     => 'border-collapse:collapse;',
  'th'        => 'background-color:#DEA;white-space:nowrap;padding:13px 13px 13px;',
  'td'        => 'background-color:#FFF;font-size:13px;line-height:20px;font-family:Georgia,serif;border-bottom:solid 1px #DEA;padding:0px 0px 20px;',
  'p'         => 'font-size:13px;line-height:20px;font-family:Georgia,serif;',
  'a'         => 'color:#696;',
  'h1'        => 'color:#696;font-size:24px;line-height:24px;margin:13px 0px;font-family:Lato,sans-serif;text-transform:uppercase;',
);


// Tabel (en velden) met email-adressen voor verzending
$config['address_table']      = 'tbl_newsletter_addresses';
$config['email_field']        = 'email_email';
$config['name_field']         = 'str_name';
$config['send_field']         = 'b_send';

?>