<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| Files belonging to this module/plugin
| (views,config and language files with same name not needed)
|--------------------------------------------------------------------------
*/

$config['_files']=array(
  'db/add_newsletter.sql',
  'site/config/plugin_newsletter.php',
  'site/libraries/plugin_newsletter.php',
  'site/models/formaction_newsletter.php',
  'site/models/newsletter_model.php',
  'site/views/newsletter/*'
);


$config['submit_form'] = array(
  'model'             => 'formaction_newsletter.fields',
  'address_table'     => 'tbl_newsletter_addresses',
  'placeholders_as_labels' => true,
  'buttons'           => array( 'submit'=>array('submit'=>'submit', 'value'=>lang('submit')) ),
  'validation_place'  => 'field',
  'check_for_spam'    => true,
  // 'add_captcha'       => true,
  'formaction'        => 'formaction_newsletter',
  'thanks'            => lang('thanks_for_submit'),
  '__return'          => ''
);

$config['unsubmit_form'] = array(
  'title'             => lang('unsubmit_to_newsletter'),
  'action_query'      => '?unsubmit',
  'fields'            => array( 'email_email'	=> array( 'label'=>lang('email_email'),  'validation'	=>  'required|valid_email' ) ),
  'address_table'     => 'tbl_newsletter_addresses',
  'placeholders_as_labels' => true,
  'buttons'           => array( 'submit'=>array('submit'=>'submit', 'value'=>lang('submit')) ),
  'validation_place'  => 'field',
  'check_for_spam'    => true,
  'formaction'        => 'formaction_newsletter',
  'thanks'            => lang('unsubmit_succes'),
  '__return'          => ''
);


$config['optin_form'] = array(
  'fields'                  => array( 'email_email'	=> array( 'label'=>lang('email_email'), 'validation'	=>  'required|valid_email' ) ),
  'address_table'           => 'tbl_newsletter_addresses',
  'placeholders_as_labels'  => true,
  'validation_place'        => 'field',
  'check_for_spam'          => true,
  // 'add_captcha'       => true,
  'buttons'                 => array( 'submit'=>array('submit'=>'submit', 'value'=>lang('submit')) ),
  'formaction'              => 'formaction_newsletter',
  // Specifieke instellingen voor: formaction
  'subject'                 => lang('optin_subject'),                    // Onderwerp van de email. Je kunt er codes inzetten die vervangen worden: %URL% = Url van de site, %MAIL% = 1e email veld, of een willekeurig veld %veldnaam%.
  'to_address_field'        => 'email_email',                            // Veld in het formulier met het emailadres van de bezoeker
  'media_optin_field'       => 'media_optin',                            // Veld in tbl_site met het optin bestand
  'thanks'                  => lang('optin_send_text'),
  '__return'                => ''
);
