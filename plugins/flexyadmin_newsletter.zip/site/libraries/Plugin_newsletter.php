<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');


/**
	* Aanmaken en versturen van nieuwsbrieven
	*
	* Onderdeel van de module newsletter
	*
	* @author Jan den Besten
	* @package FlexyAdmin_newsletter
	**/

class Plugin_newsletter extends Plugin {

  /**
  	* Wizard object
  	*
  	* @ignore
  	*/
  private $wizard;

  /**
   * @ignore
   */
  public function __construct() {
    parent::__construct();
    $this->CI->load->model('newsletter_model','model');
    $this->CI->model->initialize($this->config);
    $this->CI->load->language('newsletter');
		$this->CI->load->library('form');
		$this->CI->load->library('wizard');

    $this->set_config(array(
      'wizard_create' => array(
        'edit_text'      => array('label'=>lang('edit_text'),'method'=>'_create_edit_text'),
        'send_test'      => array('label'=>lang('send_test'),'method'=>'_create_send_test'),
        'send_it'        => array('label'=>lang('send_it'),'method'=>'_send_it')
      )
    ));

  }

  /**
   * Toont menu met opties voor het maken, en verzenden van een nieuwsletter en het exporteren van mailadressen
   *
   * @param string $args 
   * @return void
   * @author Jan den Besten
   */
	public function _admin_api($args=NULL) {
    $action=array_shift($args);
    switch($action) {
      case 'create':
        return $this->_create_newsletter($args);
        break;
      case 'export':
        return $this->_export_addresses($args);
        break;
      default:
        $menu=new Menu();
        $menu->add(array('uri'=>uri_string().'/create','name'=>lang('create_newsletter')));
        $menu->add(array('uri'=>'admin/show/grid/'.$this->config('address_table'),'name'=>lang('show_adresses')));
        $menu->add(array('uri'=>uri_string().'/export','name'=>lang('export_adresses')));
        $menu->add(array('uri'=>'admin/plugin/export/'.$this->config('address_table'),'name'=>lang('export_table')));
        return $this->view('newsletter/newsletter_main',array('title'=>lang('title'),'content'=>$menu->render()) );
    }
  }
   
  /**
   * Maakt en roept de wizard aan
   *
   * @param string $type 
   * @param string $args 
   * @return void
   * @author Jan den Besten
   * @ignore
   */
  private function _wizard($type,$args) {
    $steps=$this->config('wizard_'.$type);
    if (isset($steps) and is_array($steps)) {
      $wizard_config['steps']=$steps;
      $wizard_config['uri_segment']=5;
      $wizard_config['object']=$this;
      $wizard_config['title']=lang($type.'_newsletter');
      $this->wizard=new Wizard($wizard_config);
      array_shift($args);
      return $this->wizard->render().$this->wizard->call_step($args);
    }
    return false;
  }

  
  /**
   * Roep juiste stap aan voor het aanmaken van nieuwsbrief
   *
   * @param string $args 
   * @return void
   * @author Jan den Besten
   * @ignore
   */
	private function _create_newsletter($args) {
    return $this->_wizard('create',$args);
  }
 
  /**
   * Stap 1 van nieuwsbrief maken
   * - Maak automatisch een nieuwsbrief aan
   * - Toon formulier waarmee die nog aangepast kan worden
   *
   * @param string $args 
   * @return void
   * @author Jan den Besten
   * @ignore
   */
  public function _create_edit_text($args) {
    // Create EMAIL
    $email=$this->CI->model->create_automatic_email();
    // Put in FORM for manual adjustments
    $form=new Form();
    $formData=array(
      'str_subject' => array('value'=>$email['subject']),
      'txt_body'    => array('type'=>'htmleditor','value'=>$email['body'])
    );
    $formButtons = array( 'submit'=>array('submit'=>'submit', 'value'=>lang('submit')) );
    $form->set_data($formData,lang('edit_text'));
		$form->set_buttons($formButtons);
    if ($form->validation()) {
      $data=$form->get_data();
      $this->wizard->save_data($data);
      $redirect=site_url($this->wizard->get_next_step_uri());
      redirect($redirect);
    }
    else {
      $errors=validation_errors('<p class="error">', '</p>');
      return $this->view('newsletter/newsletter_main',array('title'=>lang('create_newsletter'),'content'=>$errors.$form->render() ));
    }
	}

  /**
   * Stap 2 voor maken van nieuwsbrief: stuur een test
   *
   * @param string $args 
   * @return void
   * @author Jan den Besten
   * @ignore
   */
  public function _create_send_test($args) {
    $data=$this->wizard->get_data();
    if ($data) {
      // Show form with (test) addresses
      $form=new Form();
      $mail=array();
      $mail['to']=$this->CI->db->get_field('tbl_site','email_email');
      $mail['from']=$mail['to'];
      $mail['subject']=$data['str_subject'];
      $mail['body']=$data['txt_body'];
      $formData=array2formfields($mail);
      $formData['body']['type']='htmleditor';
      $formButtons = array( 'submit'=>array('submit'=>'submit', 'value'=>lang('send')) );
      $form->set_data($formData,lang('send_test'));
      $form->set_buttons($formButtons);
      if ($form->validation()) {
        $mail=$form->get_data();
        $data['rapport']=$this->CI->model->send_mail($mail);
        $this->wizard->save_data($data);
        $redirect=site_url($this->wizard->get_next_step_uri());
        redirect($redirect);
        return $this->view('newsletter/newsletter_main',array('title'=>lang('send_test'),'content'=>$rapport ));
      }
      else {
        $errors=validation_errors('<p class="error">', '</p>');
        return $this->view('newsletter/newsletter_main',array('title'=>lang('send_test'),'content'=>$errors.$form->render() ));
      }
    }
  }
 

  /**
   * Stap 3 voor verzending nieuwsbrief: verstuur naar alle adressen
   *
   * @param string $args 
   * @return void
   * @author Jan den Besten
   * @ignore
   */
  public function _send_it($args) {
    $data=$this->wizard->get_data();
    if ($data) {
      // Show form with real addresses
      $form=new Form();
      $mail=array();
      $mail['to']=$this->CI->db->get_field('tbl_site','email_email');
      $mail['bcc']=$this->CI->model->get_adresses();
      $mail['from']=$this->config('from');
      if (!$mail['from']) $mail['from']=$mail['to'];
      $mail['subject']=$data['str_subject'];
      $mail['body']=$data['txt_body'];
      $formData=array2formfields($mail);
      // $formData['body']['type']='htmleditor';
      unset($formData['body']);
      $formButtons = array( 'submit'=>array('submit'=>'submit', 'value'=>lang('send')) );
      $form->set_data($formData,lang('send_it'));
      $form->set_buttons($formButtons);
      if ($form->validation()) {
        $mail=$form->get_data();
        $mail=array_merge($data,$mail);
        $mail['subject']=$mail['str_subject'];
        unset($mail['str_subject']);
        $mail['body']=$mail['txt_body'];
        unset($mail['txt_body']);
        $rapport=$this->CI->model->send_mail($mail);
        $this->wizard->unset_data($data);
        return $this->view('newsletter/newsletter_main',array('title'=>lang('send_newsletter'),'content'=>$rapport ));
      }
      else {
        $errors=validation_errors('<p class="error">', '</p>');
        return $this->view('newsletter/newsletter_main',array('title'=>lang('send_newsletter'),'content'=>lang('send_test').':'.$data['rapport'].$errors.$form->render() ));
      }
    }
  }


  /**
   * Exporteer adressen
   *
   * @param string $args 
   * @return void
   * @author Jan den Besten
   * @ignore
   */
  private function _export_addresses($args) {
    $this->add_message(lang('copy_adresses'));
    return $this->view('newsletter/export',array('title'=>lang('export_adresses'),'adresses'=>$this->CI->model->get_adresses()));
  }


  /**
   * @ignore
   * @depricated
   */
   public function get_show_type() {
		return 'form';
	}
  
  
  
  
}

?>