<?

/**
	* Nieuwsbrief
	*
	* Samen met de bijbehorende plugin kan hiermee een nieuwsbrief functie aan de site worden gekoppeld.
	* Deze module verzorgt het aan en afmelden van bezoekers aan de nieuwsbrief.
	* 
	* Ook is aanmelding mogelijk met het terugmailen van een kado-bestand. Een zogenaamde 'optin'.
	*
	* Bestanden
	* ----------------
	*
	* - db/add_newsletter.sql - database bestand met de benodigde tabel
	* - site/config/plugin_newsletter.php - Plugin voor het admin deel
	* - site/libraries/plugin_newsletter.php - Plugin voor het admin deel
	* - site/models/formaction_newsletter.php
	* - site/models/newsletter_model.php
	* - site/views/newsletter - De views en email templates
	* - site/language/##/newsletter_lang.php - Taalbestanden
	*
	* Installatie
	* ----------------
	*
	* - Zorg ergens op je site voor een (un)submit formulier door de module newsletter te koppelen aan een pagina
	* - Stel in site/config/config.php: $config['query_urls']=TRUE;
	* - Newsletter wordt automatisch toegevoegd aan het Admin menu, zorg zelf nog even voor de juiste plaats
	* 
	* @author Jan den Besten
	* @package FlexyAdmin_newsletter
	*
	*/
class Newsletter extends Module {

  /**
   * @ignore
   */
  public function __construct() {
    parent::__construct();
    $this->CI->load->model('formaction');
    $this->CI->load->model('formaction_newsletter');
  }

  /**
  	* Roept newsletter.submit aan, maar als er een unsubmit waarde bekend is dan wordt newsletter.unsubmit aangeroepen
  	*
  	* @param string $page
  	* @return string 
  	* @author Jan den Besten
  	* @ignore
  	*/
   public function index($page) {
    $out='';
    $unsubmit=$this->CI->input->get('unsubmit');
    if (!empty($unsubmit))
      $out=$this->unsubmit($page);
    else
      $out=$this->submit($page);
    return $out;
	}



  /**
  	* Verzorgt de aanmelding aan de nieuwsbrief. Toont het aanmeldformulier.
  	*
  	* @param string $page 
  	* @return void
  	* @author Jan den Besten
  	*/
  public function submit($page) {
    $this->CI->load->library('forms');
    $this->CI->forms->initialize('submit_form',$this->config['submit_form']);
    return $this->CI->forms->submit_form();
  }


  /**
  	* Verzorgd het afmelden van de nieuwsbrief.
  	*
  	* @param string $page 
  	* @return void
  	* @author Jan den Besten
  	*/
  public function unsubmit($page) {
    $this->CI->load->library('forms');
    $form_config=$this->config['unsubmit_form'];
    $form_config['action_query'].='='.$this->CI->input->get('unsubmit');
    $this->CI->forms->initialize('unsubmit_form',$form_config);
    return $this->CI->forms->unsubmit_form();
  }
  
  
  /**
   * Aanmelding op de nieuwsbrief, maar dan door gratis een bestand toegestuurd te krijgen
   *
   * @param string $page 
   * @return string
   * @author Jan den Besten
   */
  public function optin($page) {
    $this->CI->load->library('forms');
    $this->CI->forms->initialize('optin_form',$this->config['optin_form']);
    $form=$this->CI->forms->optin_form();
    if (has_string('<form',$form)) {
      $form=$this->CI->site['txt_optin'] . $form;
    }
    return $form;
  }
  
  


}

?>