<? foreach ($items as $id => $item): ?>
<tr>
  <td colspan="2">
    <a href="<?=$item['uri']?>">
      <?php if (isset($item['media_foto']) and !empty($item['media_foto'])): ?><img src="site/assets/pictures/<?=$item['media_foto']?>" alt="<?=$item['str_title']?>" width="100%"><?php endif ?>
    </a>
    <h2><?=$item['str_title']?></h2>
    <?php if (isset($item['dat_date'])): ?><a href="<?=$item['uri']?>"><b><?=$item['dat_date']?></b></a><?php endif ?>
    <?php if (isset($item['txt_text'])): ?><?=$item['txt_text']?><?php endif ?>
  </td>
</tr>
<? endforeach ?>
