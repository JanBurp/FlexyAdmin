<table width="600">
  <thead>
    <tr>
      <th align="left" valign="top"><a href="{url_url}"><h1 class="header">Nieuwsbrief van {str_title}</h1></a></th>
    </tr>
  </thead>

  <tbody>
    <tr>
      <td>hier komt nog meer tekst</td>
    </tr>
    
    <!-- ARTIKELEN -->
    <?php if (!empty($content['tbl_artikelen']['html'])): ?>
    <?=$content['tbl_artikelen']['html']?>
    <?php endif ?>

  </tbody>

  <tfoot>
    <tr>
      <th align="left">
        <a href="{url_url}">{str_title}</a><br>
        <a href="{unsubmit_url}">Klik hier als je de nieuwsbrief niet meer wilt ontvangen.</a>
      </th>
    </tr>
  </tfoot>
</table>