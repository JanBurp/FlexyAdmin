# Run this query for the newsletter plugin and module

DROP TABLE IF EXISTS tbl_newsletter_addresses;
CREATE TABLE `tbl_newsletter_addresses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `str_name` varchar(255) NOT NULL,
  `email_email` varchar(255) NOT NULL,
  `tme_added` datetime NOT NULL,
  `b_send` TINYINT(1)  NOT NULL  DEFAULT '1',
PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;


DROP TABLE IF EXISTS tbl_newsletters;
CREATE TABLE `tbl_newsletters` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `str_title` varchar(255) NOT NULL DEFAULT '',
  `dat_date` date NOT NULL,
  `txt_text` longtext NOT NULL,
  `txt_rapport` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=1 DEFAULT CHARSET=latin1;

-- Voeg ze toe als onzichtbaar in cfg_table_info
INSERT INTO `cfg_table_info` (`table`, `b_visible`, `str_order_by`, `b_pagination`, `str_fieldsets`, `str_abstract_fields`, `str_options_where`, `b_add_empty_choice`, `str_form_many_type`, `str_form_many_order`, `int_max_rows`) VALUES ('tbl_newsletters', '0', '', '1', '', '', '', '1', '', 'last', '0');
INSERT INTO `cfg_table_info` (`table`, `b_visible`, `str_order_by`, `b_pagination`, `str_fieldsets`, `str_abstract_fields`, `str_options_where`, `b_add_empty_choice`, `str_form_many_type`, `str_form_many_order`, `int_max_rows`) VALUES ('tbl_newsletter_addresses', '0', '', '1', '', '', '', '1', '', 'last', '0');
-- Voeg plugin_newsletter toe aan cfg_admin_menu
INSERT INTO `cfg_admin_menu` (`order`, `str_ui_name`, `b_visible`, `str_type`, `api`, `path`, `table`, `str_table_where`) VALUES ('6', 'Newsletter', '1', 'api', 'API_plugin_newsletter', '', NULL, NULL);
-- Voeg optin velden toe aan tbl_site
ALTER TABLE `tbl_site` ADD `txt_optin` TEXT  NOT NULL;
ALTER TABLE `tbl_site` ADD `media_optin` VARCHAR(255)  NOT NULL  AFTER `txt_optin`;

