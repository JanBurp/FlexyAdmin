PLUGIN_STRANGE_CHARS
====================

Deze plugin kan vreemde karakters vervangen naar juiste karakters. Dit kan soms voorkomen bij het omzetten van een oude database bijvoorbeeld.


@package default

@author Jan den Besten
 

files
------

- site/config/plugin_strange_chars.php
- site/libraries/plugin_strange_chars.php

PLUGIN_STRANGE_CHARS is a flexyadmin plugin - packed at 15 nov 2013 17:36
www.flexyadmin.com