Maakt een submenu
=================

Bestanden
---------

- site/config/submenu.php - Hier kun je instellen op welk level het submenu begint

Installatie
----------------

- Voeg ergens in een view (bv views/site.php) de code `<nav id="submenu"><?=$modules['submenu']?></nav>` toe
- Stel het level in in config/submenu.php
- Laad de module altijd in: `$config['autoload_modules']=array('submenu');`
- Voeg een variabele 'submenu' toe aan `$this->site: $config['site_variables']=array('submenu');`


@package default

@author Jan den Besten
	

packed files
------

- site/config/submenu.php
- site/libraries/submenu.php

'flexyadmin_submenu.zip' is a flexyadmin module - packed at 06 feb 2015 12:52
www.flexyadmin.com