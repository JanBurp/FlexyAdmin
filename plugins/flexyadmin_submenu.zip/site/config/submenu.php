<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


$config['__return']='site';

/*
|--------------------------------------------------------------------------
| Submenu level
|--------------------------------------------------------------------------
|
| Level waar het submenu begint
*/

$config['level']=1;


/* End of file config.php */
/* Location: ./system/application/config/config.php */
