Choose Language
===============

Eenvoudige module om van taal te switchen in een site.
- Werkt alleen voor twee-talige sites
- Probeert naar de huidge pagina in de andere taal te gaan, anders naar de startpagina 

Installatie:
-----------

- Voeg de module 'choose_language' toe in het menu op de pagina waar deze knop moet komen


@package default

@author Jan den Besten
 

packed files
------

- site/libraries/choose_language.php

'flexyadmin_choose_language.zip' is a flexyadmin module - packed at 06 feb 2015 13:04
www.flexyadmin.com